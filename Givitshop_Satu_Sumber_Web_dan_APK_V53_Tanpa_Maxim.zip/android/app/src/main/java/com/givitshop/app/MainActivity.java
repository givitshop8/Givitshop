package com.givitshop.app;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.net.Uri;

public class MainActivity extends Activity {
 private static final String STORE_URL = "https://givitshop8.github.io/Givitshop/";
 private WebView w;
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  setContentView(R.layout.activity_main);
  w=findViewById(R.id.webview);
  w.setWebViewClient(new WebViewClient());
  w.setWebChromeClient(new WebChromeClient());
  WebSettings s=w.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowFileAccess(false);
  s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  w.addJavascriptInterface(new ShareBridge(), "AndroidShare");
  // One shared live frontend: changes published to the website are reflected in the app too.
  w.loadUrl(STORE_URL);
 }
 public class ShareBridge {
  @JavascriptInterface
  public void share(String title, String text, String url) {
   runOnUiThread(() -> {
    String message = (text == null ? "" : text);
    if (url != null && !url.isEmpty() && !message.contains(url)) message += "\n" + url;
    Intent send = new Intent(Intent.ACTION_SEND);
    send.setType("text/plain");
    send.putExtra(Intent.EXTRA_SUBJECT, title == null ? "Givitshop" : title);
    send.putExtra(Intent.EXTRA_TEXT, message);
    startActivity(Intent.createChooser(send, "Bagikan produk melalui"));
   });
  }
 }
 @Override public void onBackPressed() {
  if(w!=null && w.canGoBack()) w.goBack(); else super.onBackPressed();
 }
}
