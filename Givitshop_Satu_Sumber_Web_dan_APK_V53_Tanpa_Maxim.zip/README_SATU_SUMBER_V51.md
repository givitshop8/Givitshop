# Givitshop V51 — satu sumber website dan aplikasi Android

Aplikasi Android membuka website Givitshop yang sama di https://givitshop8.github.io/Givitshop/.

- Perubahan tampilan/fitur web akan ikut terlihat di aplikasi setelah website berhasil dipublikasikan dan aplikasi dimuat ulang.
- Perubahan kode native Android (ikon, izin, bridge, konfigurasi APK) tetap memerlukan build APK baru.
- Fitur membutuhkan koneksi internet; versi ini tidak memakai halaman toko offline dari file lokal.
- Setelah memasukkan paket ke repository, build APK melalui GitHub Actions. Pastikan workflow publikasi GitHub Pages yang sudah ada tetap aktif.
