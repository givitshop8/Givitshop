V53 - Pilihan ekspedisi Maxim dihapus dari checkout website dan aplikasi Android. Pilihan lain dipertahankan.

Build APK: gunakan workflow .github/workflows/main.yml. Website: deploy web/index.html melalui GitHub Pages.
