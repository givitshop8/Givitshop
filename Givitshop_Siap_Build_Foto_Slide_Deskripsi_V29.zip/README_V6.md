# Givitshop Customer V6

Perbaikan galeri foto produk: gambar kartu beranda menggunakan object-fit: contain, gambar detail dipaksa tampil utuh di dalam slide, dan swipe horizontal diberi penanganan sentuhan tambahan untuk Android WebView. File web/index.html dan android/app/src/main/assets/index.html disinkronkan.

Upload ZIP ini ke root repository dan sesuaikan workflow agar menggunakan nama ZIP V6. Build APK lalu uji di perangkat.
