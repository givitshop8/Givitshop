
-- Givitshop verified product reviews
-- Run once in Supabase SQL Editor. Reviews can only be submitted for products
-- included in an order whose status is 'completed', verified by phone + access code.

create table if not exists public.product_reviews (
  id uuid primary key default gen_random_uuid(),
  order_id bigint not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  review_text text not null check (char_length(trim(review_text)) between 1 and 2000),
  created_at timestamptz not null default now(),
  unique (order_id, product_id)
);

create index if not exists product_reviews_product_created_idx
  on public.product_reviews(product_id, created_at desc);

alter table public.product_reviews enable row level security;
revoke all on public.product_reviews from anon, authenticated;

drop policy if exists "No direct product review access" on public.product_reviews;
create policy "No direct product review access"
on public.product_reviews for all to anon, authenticated
using (false) with check (false);

create or replace function public.get_my_reviewable_products(
  p_customer_phone text,
  p_access_code text
)
returns table(order_id bigint, product_id uuid, product_name text)
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  return query
  select o.id, oi.product_id, oi.product_name::text
  from public.orders as o
  join public.order_items as oi on oi.order_id = o.id
  where o.status = 'completed'
    and regexp_replace(coalesce(o.customer_phone, ''), '\D', '', 'g')
        = regexp_replace(coalesce(p_customer_phone, ''), '\D', '', 'g')
    and trim(coalesce(o.access_code::text, '')) = trim(coalesce(p_access_code, ''))
    and length(trim(coalesce(p_access_code, ''))) = 6
    and not exists (
      select 1
      from public.product_reviews as pr
      where pr.order_id = o.id and pr.product_id = oi.product_id
    )
  order by o.id desc, oi.product_name;
end;
$$;

create or replace function public.submit_verified_product_review(
  p_order_id bigint,
  p_customer_phone text,
  p_access_code text,
  p_product_id uuid,
  p_rating integer,
  p_review_text text
)
returns uuid
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_review_id uuid;
  v_review_text text := trim(coalesce(p_review_text, ''));
begin
  if p_rating is null or p_rating < 1 or p_rating > 5 then
    raise exception 'Rating harus antara 1 sampai 5.';
  end if;
  if char_length(v_review_text) < 1 or char_length(v_review_text) > 2000 then
    raise exception 'Ulasan harus berisi 1–2000 karakter.';
  end if;
  if length(trim(coalesce(p_access_code, ''))) <> 6 then
    raise exception 'Kode akses harus 6 digit.';
  end if;

  if not exists (
    select 1
    from public.orders as o
    join public.order_items as oi on oi.order_id = o.id
    where o.id = p_order_id
      and o.status = 'completed'
      and oi.product_id = p_product_id
      and regexp_replace(coalesce(o.customer_phone, ''), '\D', '', 'g')
          = regexp_replace(coalesce(p_customer_phone, ''), '\D', '', 'g')
      and trim(coalesce(o.access_code::text, '')) = trim(coalesce(p_access_code, ''))
  ) then
    raise exception 'Ulasan hanya bisa dikirim untuk produk dari pesanan selesai yang terverifikasi.';
  end if;

  insert into public.product_reviews(order_id, product_id, rating, review_text)
  values (p_order_id, p_product_id, p_rating, v_review_text)
  returning product_reviews.id into v_review_id;

  return v_review_id;
exception
  when unique_violation then
    raise exception 'Produk ini sudah kamu ulas untuk pesanan tersebut.';
end;
$$;

create or replace function public.get_product_reviews(p_product_id uuid)
returns table(rating integer, review_text text, created_at timestamptz)
language sql
security definer
set search_path = public, pg_temp
as $$
  select pr.rating, pr.review_text, pr.created_at
  from public.product_reviews as pr
  where pr.product_id = p_product_id
  order by pr.created_at desc;
$$;

revoke all on function public.get_my_reviewable_products(text, text) from public;
revoke all on function public.submit_verified_product_review(bigint, text, text, uuid, integer, text) from public;
revoke all on function public.get_product_reviews(uuid) from public;

grant execute on function public.get_my_reviewable_products(text, text) to anon, authenticated;
grant execute on function public.submit_verified_product_review(bigint, text, text, uuid, integer, text) to anon, authenticated;
grant execute on function public.get_product_reviews(uuid) to anon, authenticated;
