
/* ===== GIVITSHOP + SUPABASE =====
   Isi SUPABASE_ANON_KEY dengan Publishable/anon key dari:
   Supabase > Project Settings > API.
   JANGAN gunakan service_role key di aplikasi.
*/
const SUPABASE_URL = 'https://oaojkkhvscbufpakunrs.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_jeoQMVZMgtnJeUR9tsq8tg_owYrhU-S';

let products = [];
let productVariants = [];
let productSizes = [];
let cart = [];
let currentFilter = 'Semua';
let lastOrder = null;
let lastCustomerPhone = '';
let lastAccessCode = '';
const paymentToken = () => (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : String(Date.now())+'-'+Math.random().toString(36).slice(2));
const EDGE_FUNCTION_URL = SUPABASE_URL + '/functions/v1/cek-ongkir';
let shippingState = { destination:null, courier:'', service:'', cost:0, confirmed:false, options:[] };

const money = n => new Intl.NumberFormat('id-ID',{
  style:'currency',currency:'IDR',maximumFractionDigits:0
}).format(Number(n)||0);

async function sbFetch(path, options={}) {
  if (!SUPABASE_ANON_KEY || SUPABASE_ANON_KEY.includes('GANTI_DENGAN')) {
    throw new Error('API key Supabase belum diisi.');
  }
  const headers = Object.assign({
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': 'Bearer ' + SUPABASE_ANON_KEY,
    'Content-Type': 'application/json'
  }, options.headers || {});
  const res = await fetch(SUPABASE_URL + path, Object.assign({}, options, {headers}));
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch(e) {}
  if (!res.ok) throw new Error((data && (data.message || data.hint || data.error)) || text || ('HTTP '+res.status));
  return data;
}

async function edgeFetch(action, opts={}) {
  const headers = Object.assign({
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': 'Bearer ' + SUPABASE_ANON_KEY,
    'Content-Type': 'application/json'
  }, opts.headers || {});
  const url = EDGE_FUNCTION_URL + '?action=' + encodeURIComponent(action) + (opts.query ? '&' + opts.query : '');
  const res = await fetch(url, Object.assign({}, opts, {headers}));
  const text = await res.text();
  let data=null; try { data=text ? JSON.parse(text) : null; } catch(e) {}
  if(!res.ok) throw new Error((data && (data.error || data.message || data.hint)) || text || ('HTTP '+res.status));
  return data;
}

function cartSubtotal(){ return cart.reduce((s,i)=>s+cartLinePrice(i)*i.qty,0); }
function cartWeight(){ return cart.reduce((s,i)=>s+cartLineWeight(i)*i.qty,0); }
function roundedShippingWeight(){
  return Math.max(1000, Math.ceil(cartWeight()/1000)*1000);
}
function shippingCourierLabel(c){
  return ({jne:'JNE',jnt:'J&T',grabexpress:'GrabExpress',maxim:'Maxim'})[c] || c || '-';
}

async function searchDestination(){
  const input=document.getElementById('destinationSearch');
  const box=document.getElementById('destinationResults');
  const q=(input?.value||'').trim();
  if(!q){box.innerHTML='<div style="font-size:11px;color:#777">Masukkan kota, kecamatan, kelurahan, atau kode pos.</div>';return;}
  box.innerHTML='<div style="font-size:11px;color:#777">Mencari tujuan...</div>';
  try{
    const data=await edgeFetch('search',{query:'search='+encodeURIComponent(q)});
    const rows=Array.isArray(data?.data)?data.data:[];
    if(!rows.length){box.innerHTML='<div style="font-size:11px;color:#b42318">Tujuan tidak ditemukan.</div>';return;}
    box.innerHTML=rows.map(d=>`<button type="button" onclick="selectDestination(${Number(d.id)},'${escapeHtml(d.label||'')}', '${escapeHtml(d.subdistrict_name||'')}', '${escapeHtml(d.city_name||'')}')" style="display:block;width:100%;text-align:left;padding:10px;margin-top:6px;border:1px solid var(--line);border-radius:10px;background:#fff;font-size:11px"><b>${escapeHtml(d.label||'')}</b><br><span style="color:#777">${escapeHtml(d.subdistrict_name||'')} · ${escapeHtml(d.city_name||'')} · ${escapeHtml(d.zip_code||'')}</span></button>`).join('');
  }catch(e){box.innerHTML='<div style="font-size:11px;color:#b42318">Gagal mencari tujuan: '+escapeHtml(e.message||e)+'</div>';}
}

function selectDestination(id,label,subdistrict,city){
  shippingState.destination={id,label,subdistrict,city};
  shippingState.options=[];
  shippingState.service=''; shippingState.cost=0;
  const selected=document.getElementById('selectedDestination');
  if(selected) selected.innerHTML='<b>Tujuan:</b> '+escapeHtml(label);
  const box=document.getElementById('destinationResults'); if(box) box.innerHTML='<div style="font-size:11px;color:#2f7d32;padding:8px;background:#f0fff2;border-radius:10px">✓ Tujuan dipilih</div>';
  renderShippingOptions();
}

async function calculateCourier(courier){
  shippingState.courier=courier;
  shippingState.service=''; shippingState.cost=0; shippingState.options=[]; shippingState.confirmed=false;
  renderShippingOptions();
  if(courier==='grabexpress' || courier==='maxim') return;
  if(!shippingState.destination){alert('Pilih tujuan pengiriman terlebih dahulu.');return;}
  const box=document.getElementById('serviceResults'); if(box) box.innerHTML='<div style="font-size:11px;color:#777">Menghitung ongkir '+shippingCourierLabel(courier)+'...</div>';
  try{
    const data=await edgeFetch('cost',{method:'POST',body:JSON.stringify({origin:76640,destination:Number(shippingState.destination.id),weight:roundedShippingWeight(),courier})});
    const rows=Array.isArray(data?.data)?data.data:[];
    shippingState.options=rows;
    if(!rows.length){box.innerHTML='<div style="font-size:11px;color:#b42318">Layanan '+shippingCourierLabel(courier)+' tidak tersedia untuk tujuan ini.</div>';return;}
    box.innerHTML=rows.map((r,i)=>`<button type="button" onclick="selectService(${i})" style="display:block;width:100%;text-align:left;padding:11px;margin-top:7px;border:1px solid ${i===0?'var(--pink)':'var(--line)'};border-radius:12px;background:${i===0?'#fff7f9':'#fff'}"><b>${escapeHtml(r.service||r.name||'-')}</b><br><span style="font-size:10px;color:#777">${escapeHtml(r.description||'')} · ${escapeHtml(r.etd||'-')}</span><span style="float:right;font-weight:800;color:var(--pink)">${money(r.cost)}</span></button>`).join('');
    selectService(0);
  }catch(e){box.innerHTML='<div style="font-size:11px;color:#b42318">Gagal menghitung ongkir: '+escapeHtml(e.message||e)+'</div>';}
}

function selectService(index){
  const r=shippingState.options[index]; if(!r) return;
  shippingState.service=r.service||r.name||'Ongkir';
  shippingState.cost=Number(r.cost)||0;
  shippingState.confirmed=true;
  renderShippingSummary();
}

function renderShippingOptions(){
  const service=document.getElementById('serviceResults');
  const manual=document.getElementById('manualShippingNote');
  if(!service) return;
  if(shippingState.courier==='grabexpress' || shippingState.courier==='maxim'){
    shippingState.service='Ongkir dikonfirmasi admin'; shippingState.cost=0; shippingState.confirmed=false;
    service.innerHTML='<div style="margin-top:8px;padding:12px;border-radius:12px;background:#fff7e8;border:1px solid #f3dfb2;font-size:11px">💬 Ongkir akan dikonfirmasi admin setelah pesanan dibuat.</div>';
  } else if(shippingState.courier){
    service.innerHTML='<div style="font-size:11px;color:#777">Pilih layanan pengiriman.</div>';
  } else {
    service.innerHTML='<div style="font-size:11px;color:#777">Pilih ekspedisi.</div>';
  }
  if(manual) manual.style.display=(shippingState.courier==='grabexpress'||shippingState.courier==='maxim')?'block':'none';
  renderShippingSummary();
}

function renderShippingSummary(){
  const el=document.getElementById('shippingSummary'); if(!el) return;
  const weight=roundedShippingWeight();
  const label=shippingState.courier ? shippingCourierLabel(shippingState.courier) : 'Belum dipilih';
  const service=shippingState.service || '-';
  const cost=shippingState.courier==='grabexpress'||shippingState.courier==='maxim' ? 0 : shippingState.cost;
  el.innerHTML=`<div class="checkoutrow"><span>Berat kirim</span><b>${money(weight).replace('Rp','').trim()} g</b></div><div class="checkoutrow"><span>Ekspedisi</span><b>${escapeHtml(label)}</b></div><div class="checkoutrow"><span>Layanan</span><b>${escapeHtml(service)}</b></div><div class="checkoutrow"><span>Ongkir</span><b>${shippingState.courier==='grabexpress'||shippingState.courier==='maxim'?'Menunggu konfirmasi':money(cost)}</b></div>`;
  const totalEl=document.getElementById('checkoutTotal');
  if(totalEl) totalEl.textContent=money(cartSubtotal()+cost);
}

function productType(p) {
  const s = (p.name || '').toLowerCase();
  return /serum|sunscreen|toner|spray|shampoo|conditioner|lip|cream tube|bottle/.test(s) ? 'bottle' : 'jar';
}

function productImage(p, cls='') {
  return p.image_url
    ? `<img class="productimg ${cls}" src="${p.image_url}" alt="${escapeHtml(p.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><div class="${productType(p)} fallback"></div>`
    : `<div class="${productType(p)}"></div>`;
}

function productPriceLabel(p){
  const os=(p.options||[]).filter(o=>Number(o.stock)>0 && o.is_active!==false);
  if(os.length){const prices=os.map(o=>Number(o.price)||0);const min=Math.min(...prices),max=Math.max(...prices);return min===max?money(min):money(min)+' - '+money(max)}
  const vs=(p.variants||[]).filter(v=>v.is_active!==false);
  if(!vs.length)return money(p.price);const prices=vs.map(v=>Number(v.price??p.price)).filter(Number.isFinite);const min=Math.min(...prices),max=Math.max(...prices);return min===max?money(min):money(min)+' - '+money(max);
}
function variantForCart(item){return item.variant_id?(products.find(p=>String(p.id)===String(item.product_id))?.variants||[]).find(v=>String(v.id)===String(item.variant_id)):null}
function optionForCart(item){const p=products.find(x=>String(x.id)===String(item.product_id));if(!p||!item.variant_id||!item.size_name)return null;const sid=(p.sizes||[]).find(s=>String(s.name).toLowerCase()===String(item.size_name).toLowerCase())?.id;return (p.options||[]).find(o=>String(o.variant_id)===String(item.variant_id)&&String(o.size_id)===String(sid))||null}
function cartLinePrice(i){const p=products.find(x=>String(x.id)===String(i.product_id));const o=optionForCart(i),v=variantForCart(i);return Number(o?.price??v?.price??p?.price)||0}
function cartLineWeight(i){const p=products.find(x=>String(x.id)===String(i.product_id));const o=optionForCart(i),v=variantForCart(i);return Number(o?.weight_grams??v?.weight_grams??p?.weight_grams)||1000}
function cartLineStock(i){const p=products.find(x=>String(x.id)===String(i.product_id));const o=optionForCart(i),v=variantForCart(i);return Number(o?.stock??v?.stock??p?.stock)||0}
function cartLineKey(productId,variantId,sizeName){return [productId,variantId||'',sizeName||''].join('|')}

function escapeHtml(s='') {
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}

async function loadProducts() {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '<div class="empty">Memuat produk...</div>';
  try {
    const [data, variants, sizes, options, productImages] = await Promise.all([
      sbFetch('/rest/v1/products?select=*&is_active=eq.true&order=created_at.desc'),
      sbFetch('/rest/v1/product_variants?select=*&is_active=eq.true&order=created_at.asc'),
      sbFetch('/rest/v1/product_sizes?select=*&is_active=eq.true&order=created_at.asc'),
      sbFetch('/rest/v1/product_variant_options?select=*&is_active=eq.true&order=created_at.asc'),
      sbFetch('/rest/v1/product_images?select=*&is_active=eq.true&order=sort_order.asc')
    ]);
    products = Array.isArray(data) ? data : [];
    productVariants = Array.isArray(variants) ? variants : [];
    productSizes = Array.isArray(sizes) ? sizes : [];
    const productOptions = Array.isArray(options) ? options : [];
    const allProductImages = Array.isArray(productImages) ? productImages : [];
    products.forEach(p=>{p.images=allProductImages.filter(x=>String(x.product_id)===String(p.id)).sort((a,b)=>Number(a.sort_order||0)-Number(b.sort_order||0));p.variants=productVariants.filter(v=>String(v.product_id)===String(p.id));p.sizes=productSizes.filter(x=>String(x.product_id)===String(p.id));p.options=productOptions.filter(o=>String(o.product_id)===String(p.id));});
    renderProducts();
    updateCartBadges();
  } catch (e) {
    console.error(e);
    grid.innerHTML = `<div class="empty"><h3>Produk belum dapat dimuat</h3><p style="font-size:11px">${escapeHtml(e.message)}</p><button class="cta" onclick="loadProducts()">Coba Lagi</button></div>`;
  }
}

function cartItemCount(){return cart.reduce((n,i)=>n+(Number(i.qty)||0),0)}
function updateCartBadges(){const n=cartItemCount();['headerCartBadge','navCartBadge','detailCartBadge'].forEach(id=>{const el=document.getElementById(id);if(!el)return;el.textContent=n>99?'99+':String(n);el.style.display='flex'})}
function closeAddModal(){const el=document.getElementById('addModal');if(el)el.remove()}
function openAddModal(){
  const st=window.detailState;if(!st)return;
  const p=products.find(x=>String(x.id)===String(st.productId));if(!p)return;
  const v=(p.variants||[]).find(x=>String(x.id)===String(st.variantId));
  const o=selectedOption();
  const stock=Number(o?.stock??v?.stock??p.stock)||0;
  const html=`<div id="addModal" class="modalback" onclick="if(event.target===this)closeAddModal()"><div class="modal">
    <div class="modalhead"><div class="modalthumb">${productImage(o?.image_url||v?.image_url?{...p,image_url:o?.image_url||v?.image_url}:p)}</div><div class="modaltitle"><b style="font-size:13px">${escapeHtml(p.name)}</b><div id="modalPrice" class="price" style="font-size:20px;margin-top:4px">${money(Number(o?.price??v?.price??p.price)||0)}</div></div><button class="closebtn" onclick="closeAddModal()">×</button></div>
    <div style="margin-top:14px"><b style="font-size:12px">Varian</b><div style="display:flex;flex-wrap:wrap;gap:7px;margin-top:8px">${(p.variants||[]).filter(x=>x.is_active!==false).map(x=>`<button type="button" class="optionbtn ${String(x.id)===String(st.variantId)?'selected':''}" onclick="closeAddModal();selectVariant('${x.id}');openAddModal()">${escapeHtml(x.name)}</button>`).join('')}</div></div>
    ${(p.sizes||[]).length?`<div style="margin-top:14px"><b style="font-size:12px">Ukuran</b><div style="display:flex;flex-wrap:wrap;gap:7px;margin-top:8px">${(p.sizes||[]).filter(x=>x.is_active!==false).map(x=>{const szopt=(p.options||[]).find(q=>String(q.variant_id)===String(st.variantId)&&String(q.size_id)===String(x.id));const av=!p.options?.length||Number(szopt?.stock)>0;return `<button type="button" class="optionbtn ${String(x.name)===String(st.sizeName)?'selected':''}" ${av?'':'disabled'} onclick="closeAddModal();selectSize('${escapeHtml(x.name)}');openAddModal()">${escapeHtml(x.name)}</button>`}).join('')}</div></div>`:''}
    <div style="margin-top:14px"><b style="font-size:12px">Jumlah</b><div class="qty"><button onclick="closeAddModal();detailQty(-1);openAddModal()">−</button><span>${st.qty}</span><button onclick="closeAddModal();detailQty(1);openAddModal()">+</button><span style="font-size:11px;color:#777">Stok tersedia: ${stock}</span></div></div>
    <button type="button" class="cta" style="width:100%;margin-top:18px;padding:14px" onclick="confirmAddFromModal()">🛒 Masukkan Keranjang</button>
  </div></div>`;
  document.body.insertAdjacentHTML('beforeend',html);
}
function confirmAddFromModal(){const before=cartItemCount();addFromDetail();if(cartItemCount()>before){closeAddModal();showAddedSuccess()}}
function showAddedSuccess(){const st=window.detailState;if(!st)return;const p=products.find(x=>String(x.id)===String(st.productId));const v=(p?.variants||[]).find(x=>String(x.id)===String(st.variantId));const o=selectedOption();const img=o?.image_url||v?.image_url||p?.image_url;document.body.insertAdjacentHTML('beforeend',`<div id="successModal" class="modalback successmodal"><div class="modal"><div class="successicon">✅</div><h2 style="margin:0 0 8px">Berhasil Ditambahkan</h2><div style="font-size:13px;color:#555">${escapeHtml(p?.name||'Produk')}</div><div style="font-size:12px;color:#777;margin-top:4px">${escapeHtml(v?.name||'')} ${st.sizeName?'• '+escapeHtml(st.sizeName):''} • Jumlah ${st.qty}</div><div class="successactions"><button style="background:#fff0f4;color:var(--pink)" onclick="document.getElementById('successModal').remove();show('detail')">Lanjut Belanja</button><button style="background:var(--pink);color:#fff" onclick="document.getElementById('successModal').remove();show('cart')">Lihat Keranjang</button></div></div></div>`)}

function renderProducts() {
  const input = document.getElementById('search');
  const q = (input ? input.value : '').toLowerCase();
  const list = products.filter(p =>
    (currentFilter==='Semua' || (p.category||'')===currentFilter) &&
    (`${p.name||''} ${p.brand||''} ${p.category||''}`.toLowerCase().includes(q))
  );
  document.getElementById('productGrid').innerHTML =
    list.map(p => `<article class="product">
      <div class="pic" onclick="detail('${p.id}')">
        <button class="heart" onclick="event.stopPropagation()">♡</button>
        ${productImage(p)}
      </div>
      <div class="pbody">
        <div class="pname">${escapeHtml(p.name)}</div>
        <div style="font-size:10px;color:#777">${escapeHtml(p.brand||p.category||'')}</div>
        <div class="rating">★ 4.9 · Stok ${Number(p.stock)||0}</div>
        <div class="price">${productPriceLabel(p)}</div>
        <button class="add" onclick="add('${p.id}')">+ Keranjang</button>
      </div>
    </article>`).join('') || '<div class="empty">Produk tidak ditemukan.</div>';
}

function filterCat(c) {
  currentFilter=c;
  document.querySelectorAll('.chip').forEach(x=>x.classList.remove('active'));
  renderProducts();
}

function productGalleryImages(p, selectedUrl=''){
  const base=(p.images||[]).map(x=>x.image_url).filter(Boolean);
  if(!base.length && p.image_url) base.push(p.image_url);
  if(selectedUrl && !base.includes(selectedUrl)) base.unshift(selectedUrl);
  return [...new Set(base)];
}
function setDetailImage(index){
  const st=window.detailState;if(!st)return;
  const p=products.find(x=>String(x.id)===String(st.productId));if(!p)return;
  const imgs=productGalleryImages(p, selectedOption()?.image_url||variantForCart({product_id:p.id,variant_id:st.variantId})?.image_url||'');
  st.galleryIndex=Math.max(0,Math.min(Number(index)||0,imgs.length-1));
  const img=document.getElementById('detailMainImage');if(img&&imgs[st.galleryIndex])img.src=imgs[st.galleryIndex];
  document.querySelectorAll('.gallerythumb').forEach((x,i)=>x.classList.toggle('active',i===st.galleryIndex));
  document.querySelectorAll('.gallerydot').forEach((x,i)=>x.classList.toggle('active',i===st.galleryIndex));
}
function formatDescription(text=''){
  return escapeHtml(String(text).replace(/\\r\\n/g,'\\n').replace(/\\r/g,'\\n')).replace(/\\n{2,}/g,'\\n\\n');
}
function toggleDescription(){const el=document.getElementById('productDescription');const b=document.getElementById('readMoreBtn');if(!el||!b)return;const collapsed=el.classList.toggle('collapsed');b.textContent=collapsed?'Baca Selengkapnya ↓':'Sembunyikan ↑';}
function detail(id){
 const p=products.find(x=>String(x.id)===String(id));if(!p)return;
 const vs=(p.variants||[]).filter(v=>v.is_active!==false),sizes=(p.sizes||[]).filter(x=>x.is_active!==false);
 const defaultVariant=vs[0]||null;const defaultSize=sizes[0]?.name||'';
 const imgs=productGalleryImages(p,defaultVariant?.image_url||'');
 const gallery=imgs.length?`<div class="detailgallery"><div class="detailpic"><img id="detailMainImage" class="productimg" src="${escapeHtml(imgs[0])}" alt="${escapeHtml(p.name)}"></div>${imgs.length>1?`<div class="gallerydots">${imgs.map((_,i)=>`<span class="gallerydot ${i===0?'active':''}"></span>`).join('')}</div><div class="gallerythumbs">${imgs.map((u,i)=>`<button class="gallerythumb ${i===0?'active':''}" onclick="setDetailImage(${i})"><img src="${escapeHtml(u)}" alt="Foto ${i+1}"></button>`).join('')}</div>`:''}</div>`:`<div class="detailgallery"><div class="detailpic">${productImage(defaultVariant?.image_url?{...p,image_url:defaultVariant.image_url}:p)}</div></div>`;
 const desc=String(p.description||'Produk pilihan Givitshop. Informasi produk dapat diperbarui dari database.');
 document.getElementById('detail').innerHTML=`<div class="detailhead"><button class="backbtn" onclick="show('home')">← Kembali</button><b style="font-family:Georgia,serif;color:var(--pink);font-size:21px">Givitshop</b><button class="detailcartbtn" onclick="show('cart')"><span class="carticonwrap">🛒<span id="detailCartBadge" class="cartbadge" style="display:none">0</span></span></button></div>${gallery}<div class="detail"><div style="font-size:11px;color:#777">${escapeHtml(p.brand||p.category||'')}</div><h1>${escapeHtml(p.name)}</h1><div class="rating">★ 4.9 · Stok ${Number(p.stock)||0}</div><div id="variantPrice" class="price" style="font-size:22px">${productPriceLabel(p)}</div><h3 style="font-size:14px;margin:18px 0 8px">Deskripsi Produk</h3><div id="productDescription" class="desc ${desc.length>420?'collapsed':''}">${formatDescription(desc)}</div>${desc.length>420?`<button id="readMoreBtn" class="readmore" onclick="toggleDescription()">Baca Selengkapnya ↓</button>`:''}${vs.length?`<div style="margin-top:14px"><b style="font-size:12px">Varian</b><div id="variantChoices" style="display:flex;flex-wrap:wrap;gap:7px;margin-top:8px">${vs.map((v,i)=>`<button type="button" class="optionbtn ${i===0?'selected':''}" onclick="selectVariant('${v.id}')">${escapeHtml(v.name)}</button>`).join('')}</div></div>`:''}${sizes.length?`<div style="margin-top:14px"><b style="font-size:12px">Ukuran</b><div id="sizeChoices" style="display:flex;flex-wrap:wrap;gap:7px;margin-top:8px">${sizes.map((x,i)=>`<button type="button" class="optionbtn ${i===0?'selected':''}" onclick="selectSize('${escapeHtml(x.name)}')">${escapeHtml(x.name)}</button>`).join('')}</div></div>`:''}<div style="margin-top:14px"><b style="font-size:12px">Jumlah</b><div class="qty" style="margin-top:8px"><button onclick="detailQty(-1)">−</button><span id="detailQty">1</span><button onclick="detailQty(1)">+</button><span id="detailStock" style="font-size:11px;color:#777"></span></div></div></div><div class="addfloat"><button onclick="openAddModal()">🛒 Masukkan Keranjang</button></div>`;
 window.detailState={productId:p.id,variantId:defaultVariant?.id||'',sizeName:defaultSize,qty:1,galleryIndex:0};updateDetailSelection();updateDetailCartBadge();show('detail')
}
function updateDetailCartBadge(){const el=document.getElementById('detailCartBadge');if(!el)return;const n=cartItemCount();el.textContent=n>99?'99+':n;el.style.display='flex'}

function selectedOption(){const st=window.detailState;if(!st)return null;const p=products.find(x=>String(x.id)===String(st.productId));if(!p)return null;const size=(p.sizes||[]).find(x=>String(x.name).toLowerCase()===String(st.sizeName).toLowerCase());return (p.options||[]).find(o=>String(o.variant_id)===String(st.variantId)&&(!st.sizeName||String(o.size_id)===String(size?.id)))||null}
function updateDetailSelection(){const st=window.detailState;if(!st)return;const p=products.find(x=>String(x.id)===String(st.productId));if(!p)return;const v=(p.variants||[]).find(x=>String(x.id)===String(st.variantId));const o=selectedOption();const price=Number(o?.price??v?.price??p.price)||0;document.querySelectorAll('#variantChoices .optionbtn').forEach(b=>b.classList.toggle('selected',b.getAttribute('onclick')?.includes(`'${st.variantId}'`)));document.querySelectorAll('#sizeChoices .optionbtn').forEach(b=>{const name=b.textContent.trim();const sz=(p.sizes||[]).find(x=>String(x.name)===name);const available=!p.options?.length||p.options.some(x=>String(x.variant_id)===String(st.variantId)&&String(x.size_id)===String(sz?.id)&&Number(x.stock)>0);b.disabled=!available;b.style.opacity=available?'1':'.45';b.classList.toggle('selected',name===st.sizeName)});const pe=document.getElementById('variantPrice'),pb=document.getElementById('detailBottomPrice');if(pe)pe.textContent=money(price);if(pb)pb.textContent=money(price);const stock=Number(o?.stock??v?.stock??p.stock)||0;const se=document.getElementById('detailStock');if(se)se.textContent=`tersedia ${stock} pcs`;const pic=document.getElementById('detailMainImage');if(pic&&(o?.image_url||v?.image_url))pic.src=o?.image_url||v.image_url}
function selectVariant(variantId){if(!window.detailState)return;window.detailState.variantId=variantId;window.detailState.qty=1;const p=products.find(x=>String(x.id)===String(window.detailState.productId));const first=(p?.sizes||[]).find(s=>(p.options||[]).some(o=>String(o.variant_id)===String(variantId)&&String(o.size_id)===String(s.id)&&Number(o.stock)>0));if(first)window.detailState.sizeName=first.name;updateDetailSelection()}
function selectSize(name){if(!window.detailState)return;window.detailState.sizeName=name;window.detailState.qty=1;updateDetailSelection()}
function detailQty(d){const st=window.detailState;if(!st)return;const stock=Number(selectedOption()?.stock??variantForCart({product_id:st.productId,variant_id:st.variantId})?.stock??products.find(x=>String(x.id)===String(st.productId))?.stock)||0;st.qty=Math.max(1,Math.min(stock,st.qty+d));const el=document.getElementById('detailQty');if(el)el.textContent=st.qty}
function addFromDetail(){const st=window.detailState;if(!st)return;const p=products.find(x=>String(x.id)===String(st.productId));const o=selectedOption();const v=(p?.variants||[]).find(x=>String(x.id)===String(st.variantId));const stock=Number(o?.stock??v?.stock??p?.stock)||0;if((p?.options||[]).length&&!o){alert('Pilih varian dan ukuran yang tersedia.');return}if(stock<=0){alert('Kombinasi ini sedang habis.');return}const key=cartLineKey(p.id,st.variantId,st.sizeName);let x=cart.find(i=>i.key===key);if(!x){x={key,product_id:p.id,variant_id:st.variantId||null,size_name:st.sizeName||'',qty:0};cart.push(x)}if(x.qty+st.qty>stock){alert('Jumlah melebihi stok kombinasi.');return}x.qty+=st.qty;renderCart();updateCartBadges();}

function add(id) {
  const p=products.find(x=>String(x.id)===String(id)); if(!p)return;
  const vs=(p.variants||[]).filter(v=>v.is_active!==false);
  if(vs.length){detail(id);return;}
  if(Number(p.stock)<=0){alert('Stok produk sedang habis.');return;}
  const key=cartLineKey(p.id,null,'');let x=cart.find(i=>i.key===key);if(x){if(x.qty>=Number(p.stock)){alert('Jumlah melebihi stok.');return;}x.qty++;}else cart.push({key,product_id:p.id,variant_id:null,size_name:'',qty:1});renderCart();
}

function renderCart() {
  const c=document.getElementById('cart');
  if(!cart.length){updateCartBadges();c.innerHTML='<div class="carthead"><button class="backbtn" onclick="show(\'home\')">←</button><b>Keranjang Belanja</b><button class="cartheadicon" onclick="show(\'home\')">⌂</button></div><div class="empty">🛒<h3>Keranjang masih kosong</h3><p>Yuk pilih produk favoritmu.</p><button class="cta" onclick="show(\'home\')">Mulai Belanja</button></div>';return;}
  const total=cartSubtotal();
  updateCartBadges();c.innerHTML='<div class="carthead"><button class="backbtn" onclick="show(\'home\')">←</button><b>Keranjang Belanja</b><button class="cartheadicon" onclick="show(\'home\')">⌂</button></div><div class="section">'+cart.map(i=>{const p=products.find(x=>String(x.id)===String(i.product_id));if(!p)return '';const v=variantForCart(i);const opts=[v?.name,i.size_name].filter(Boolean).join(' • ');return `<div class="cartrow"><div class="thumb">${productImage(v?.image_url?{...p,image_url:v.image_url}:p)}</div><div class="cartinfo"><b style="font-size:12px">${escapeHtml(p.name)}</b>${opts?`<div style="font-size:10px;color:#777;margin-top:3px">${escapeHtml(opts)}</div>`:''}<div class="price">${money(cartLinePrice(i))}</div><div class="qty"><button onclick="changeQty('${i.key}',-1)">−</button><span>${i.qty}</span><button onclick="changeQty('${i.key}',1)">+</button></div></div></div>`}).join('')+'</div><div class="checkout"><div class="checkoutrow"><span>Subtotal</span><b>'+money(total)+'</b></div><div class="checkoutrow"><span>Ongkir</span><span>Dihitung saat checkout</span></div><hr><div class="checkoutrow"><b>Total Produk</b><span class="total">'+money(total)+'</span></div><button class="cta" style="width:100%;margin-top:10px" onclick="showCheckout()">Checkout</button></div>';
}

function changeQty(key,d) {
  const x=cart.find(i=>i.key===key);if(!x)return;const stock=cartLineStock(x);x.qty+=d;if(x.qty>stock)x.qty=stock;if(x.qty<=0)cart=cart.filter(i=>i.key!==key);renderCart();updateCartBadges();updateDetailCartBadge();
}

function showCheckout() {
  if(!cart.length) return;
  shippingState={destination:null,courier:'',service:'',cost:0,confirmed:false,options:[]};
  document.getElementById('checkout').innerHTML=
    `<div class="back" onclick="show('cart')">‹ Checkout</div>
     <div class="checkout">
       <b>Data Pengiriman</b>
       <input id="custName" placeholder="Nama lengkap" style="width:100%;padding:12px;margin-top:10px;border:1px solid var(--line);border-radius:10px">
       <input id="custPhone" placeholder="Nomor WhatsApp" style="width:100%;padding:12px;margin-top:8px;border:1px solid var(--line);border-radius:10px">
       <textarea id="custAddress" placeholder="Alamat lengkap pengiriman" style="width:100%;height:90px;padding:12px;margin-top:8px;border:1px solid var(--line);border-radius:10px;resize:none"></textarea>
       <hr><b>Tujuan Pengiriman</b>
       <div style="display:flex;gap:7px;margin-top:8px"><input id="destinationSearch" placeholder="Contoh: Balikpapan, Tarakan, Karang Rejo, 77112" style="flex:1;padding:12px;border:1px solid var(--line);border-radius:10px"><button type="button" class="cta" onclick="searchDestination()">Cari</button></div>
       <div id="destinationResults" style="margin-top:5px"></div>
       <div id="selectedDestination" style="margin-top:8px;font-size:11px;color:#555"></div>
       <hr><b>Pilih Ekspedisi</b>
       <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px">
         <button type="button" onclick="calculateCourier('jne')" style="padding:12px;border:1px solid var(--line);border-radius:12px;background:#fff;text-align:left"><b>🚚 JNE</b><br><span style="font-size:10px;color:#777">Ongkir otomatis</span></button>
         <button type="button" onclick="calculateCourier('jnt')" style="padding:12px;border:1px solid var(--line);border-radius:12px;background:#fff;text-align:left"><b>🚚 J&T</b><br><span style="font-size:10px;color:#777">Ongkir otomatis</span></button>
         <button type="button" onclick="calculateCourier('grabexpress')" style="padding:12px;border:1px solid var(--line);border-radius:12px;background:#fff;text-align:left"><b>🚗 GrabExpress</b><br><span style="font-size:10px;color:#777">Konfirmasi admin</span></button>
         <button type="button" onclick="calculateCourier('maxim')" style="padding:12px;border:1px solid var(--line);border-radius:12px;background:#fff;text-align:left"><b>🛵 Maxim</b><br><span style="font-size:10px;color:#777">Konfirmasi admin</span></button>
       </div>
       <div id="serviceResults" style="margin-top:8px"><div style="font-size:11px;color:#777">Pilih ekspedisi.</div></div>
       <div id="manualShippingNote" style="display:none"></div>
       <div id="shippingSummary" style="margin-top:10px;padding:12px;border-radius:12px;background:#faf8f9"></div>
       <hr><b>Metode Pembayaran</b><div style="margin-top:8px;padding:12px;border:1px solid var(--pink);border-radius:12px;background:#fff7f9"><b>▣ QRIS GIVIT SHOP</b><div style="font-size:11px;color:#777;margin-top:4px">Bayar dengan aplikasi bank atau e-wallet yang mendukung QRIS.</div></div>
       <div class="checkoutrow"><b>Total Pesanan</b><span id="checkoutTotal" class="total">${money(cartSubtotal())}</span></div>
       <button id="orderBtn" type="button" class="cta" style="width:100%;margin-top:10px" onclick="placeOrder()">Buat Pesanan</button><div id="orderError" style="display:none;margin-top:10px;padding:10px;border-radius:10px;background:#fff0f0;color:#b42318;font-size:11px"></div>
     </div>`;
  renderShippingSummary();
  show('checkout');
}

async function placeOrder() {
  const customer_name=document.getElementById('custName').value.trim();
  const customer_phone=document.getElementById('custPhone').value.trim();
  const customer_address=document.getElementById('custAddress').value.trim();
  if(!customer_name || !customer_phone || !customer_address){alert('Lengkapi nama, nomor WhatsApp, dan alamat.');return;}
  const btn=document.getElementById('orderBtn'); btn.disabled=true; btn.textContent='Menyimpan pesanan...';
  try {
    const items=cart.map(i=>({product_id:i.product_id,variant_id:i.variant_id||null,size_name:i.size_name||null,quantity:i.qty}));
    const shippingIsManual = shippingState.courier==='grabexpress' || shippingState.courier==='maxim';
    if(!shippingState.courier){throw new Error('Pilih ekspedisi terlebih dahulu.');}
    if(!shippingState.destination){throw new Error('Pilih tujuan pengiriman terlebih dahulu.');}
    if(!shippingIsManual && !shippingState.service){throw new Error('Pilih layanan pengiriman terlebih dahulu.');}
    const shippingCost = shippingIsManual ? 0 : Number(shippingState.cost||0);
    const total=items.reduce((s,i)=>s+i.subtotal,0)+shippingCost;
    const token=paymentToken();
    const order=await sbFetch('/rest/v1/rpc/place_order',{
      method:'POST',
      body:JSON.stringify({
        p_customer_name:customer_name,
        p_customer_phone:customer_phone,
        p_customer_address:customer_address,
        p_payment_token:token,
        p_items:items,
        p_shipping_courier:shippingState.courier,
        p_shipping_service:shippingState.service || (shippingIsManual ? 'Ongkir dikonfirmasi admin' : 'Ongkir'),
        p_shipping_cost:shippingCost
      })
    });
    if(!order || !order.id) throw new Error('Order tidak mengembalikan ID.');

    // Ambil kode akses 6 digit dari database setelah order berhasil dibuat.
    try {
      const codeResult=await sbFetch('/rest/v1/rpc/get_order_access_code',{
        method:'POST',
        body:JSON.stringify({p_order_id:order.id,p_payment_token:token})
      });
      const accessCode=typeof codeResult==='string'
        ? codeResult
        : (Array.isArray(codeResult) ? codeResult[0] : codeResult);
      order.access_code=String(accessCode||'');
    } catch(e) {
      order.access_code='';
    }

    lastOrder=order;
    lastCustomerPhone=customer_phone;
    lastAccessCode=order.access_code||'';
    cart=[];
    renderCart();
    if(!order.shipping_confirmed){
      showShippingPending(order);
    } else {
      showPayment(order);
    }

  } catch(e) {
    const msg='Pesanan gagal disimpan: '+(e && e.message ? e.message : e);
    const err=document.getElementById('orderError');
    if(err){err.style.display='block';err.textContent=msg;}
    btn.disabled=false; btn.textContent='Buat Pesanan';
  }
}


function showShippingPending(order){
  const total=Number(order.total_amount)||0;
  document.getElementById('orders').innerHTML=
    `<div class="back" onclick="show('home')">‹ Kembali ke Beranda</div>
     <div class="qriscard">
       <div style="font-size:12px;color:#777">Pesanan #${order.id}</div>
       <h2 style="margin:6px 0">Menunggu Konfirmasi Ongkir</h2>
       <div style="font-size:34px;margin:12px">🚗 🛵</div>
       <p style="font-size:12px;color:#6f6a70">Pesanan ${escapeHtml(shippingCourierLabel(order.shipping_courier))} sudah dibuat. Admin akan mengonfirmasi ongkir terlebih dahulu.</p>
       <div style="padding:12px;border-radius:12px;background:#fff7e8;border:1px solid #f3dfb2;font-size:12px;text-align:left"><b>Nominal sementara:</b> ${money(total)}<br><span style="font-size:11px;color:#777">Total final akan berubah setelah ongkir dikonfirmasi admin.</span></div>
       <div style="margin:12px 0;padding:12px;border:2px dashed var(--pink);border-radius:12px;background:#fff7f9;text-align:center"><div style="font-size:11px;color:#777">KODE AKSES PESANAN</div><div style="font-size:25px;font-weight:800;letter-spacing:4px;margin-top:3px">${escapeHtml(order.access_code||'-')}</div><div style="font-size:10px;color:#777;margin-top:4px">Simpan kode ini untuk melihat Pesanan Saya.</div></div>
       <button class="paybtn" onclick="showMyOrders(lastCustomerPhone,lastAccessCode)">Cek Pesanan Saya</button>
       <button class="secondarybtn" onclick="show('home')">Kembali ke Beranda</button>
     </div>`;
  show('orders');
}

function showPayment(order){
  const total=Number(order.total_amount)||0;
  document.getElementById('orders').innerHTML=
    `<div class="back" onclick="show('home')">‹ Kembali ke Beranda</div>
     <div class="qriscard">
       <div style="font-size:12px;color:#777">Pesanan #${order.id}</div>
       <h2 style="margin:6px 0">Pembayaran QRIS</h2>
       <div class="qrisamount">${money(total)}</div>
       <div style="margin:12px 0;padding:12px;border:2px dashed var(--pink);border-radius:12px;background:#fff7f9;text-align:center">
         <div style="font-size:11px;color:#777">KODE AKSES PESANAN</div>
         <div style="font-size:25px;font-weight:800;letter-spacing:4px;margin-top:3px">${escapeHtml(order.access_code||'-')}</div>
         <div style="font-size:10px;color:#777;margin-top:4px">Simpan kode ini untuk melihat Pesanan Saya.</div>
       </div>
       <div class="qrisnote">Bayar tepat sebesar <b>${money(total)}</b> dengan scan QRIS di bawah.</div>
       <img class="qrisimg" src="qris_givitshop.png" alt="QRIS GIVIT SHOP">
       <div class="qrisnote">GIVIT SHOP • NMID ID1025372324331</div>
       <div class="qrisstatus">
         <b>Langkah pembayaran</b><br>
         1. Buka aplikasi bank/e-wallet yang mendukung QRIS.<br>
         2. Scan QRIS GIVIT SHOP.<br>
         3. Masukkan nominal <b>${money(total)}</b>.<br>
         4. Selesaikan pembayaran, lalu tekan tombol di bawah.
       </div>
       <button class="paybtn" onclick="confirmPayment(${order.id},'${escapeHtml(order.payment_token||'')}')">Saya sudah bayar</button>
       <button class="secondarybtn" onclick="show('home')">Bayar nanti</button>
     </div>`;
  show('orders');
}

async function confirmPayment(orderId, token){
  if(!token){alert('Token pembayaran tidak tersedia. Silakan buat pesanan baru.');return;}
  try{
    await sbFetch('/rest/v1/rpc/confirm_order_payment',{
      method:'POST',
      body:JSON.stringify({p_order_id:orderId,p_payment_token:token})
    });
    document.getElementById('orders').innerHTML=
      `<div class="back" onclick="show('home')">‹ Kembali ke Beranda</div>
       <div class="qriscard">
         <div style="font-size:38px">✓</div>
         <h2>Pembayaran dikonfirmasi</h2>
         <p style="font-size:12px;color:#6f6a70">Pesanan #${orderId} sudah ditandai <b>Menunggu verifikasi</b>.</p>
         <div style="margin:12px 0;padding:12px;border:2px dashed var(--pink);border-radius:12px;background:#fff7f9;text-align:center">
           <div style="font-size:11px;color:#777">KODE AKSES PESANAN</div>
           <div style="font-size:25px;font-weight:800;letter-spacing:4px;margin-top:3px">${escapeHtml(lastAccessCode||'-')}</div>
           <div style="font-size:10px;color:#777;margin-top:4px">Simpan kode ini untuk melihat Pesanan Saya.</div>
         </div>
         <div class="qrisstatus">Admin Givitshop akan memeriksa pembayaran sebelum pesanan diproses.</div>
         <button class="paybtn" onclick="showOrderStatus(${orderId},lastCustomerPhone)">Lihat Status Pesanan</button>
          <button class="secondarybtn" onclick="show('home')">Kembali ke Beranda</button>
       </div>`;
  }catch(e){
    alert('Konfirmasi pembayaran gagal: '+e.message);
  }
}

function show(v){
  document.querySelectorAll('.view').forEach(x=>x.classList.remove('active'));
  document.getElementById(v).classList.add('active');
  document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.v===v));
  updateCartBadges();if(v==='cart')renderCart();
  if(v==='account')renderAccount();
  scrollTo(0,0);
}


const orderStatusLabel = {
  pending: 'Menunggu',
  processing: 'Diproses',
  shipped: 'Dikirim',
  completed: 'Selesai',
  cancelled: 'Dibatalkan'
};

const paymentStatusLabel = {
  unpaid: 'Belum dibayar',
  awaiting_verification: 'Menunggu verifikasi',
  paid: 'Sudah dibayar'
};


async function showMyOrders(phone='', accessCode=''){
  show('account');
  const section=document.getElementById('account');
  section.innerHTML='<div class="back" onclick="renderAccount()">‹ Kembali</div><div class="section"><div class="sectionhead"><h2>Pesanan Saya</h2></div><div class="checkout"><input id="ordersPhone" inputmode="tel" value="'+escapeHtml(phone||'')+'" placeholder="Nomor WhatsApp saat checkout" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:10px"><input id="ordersAccessCode" inputmode="numeric" maxlength="6" value="'+escapeHtml(accessCode||'')+'" placeholder="Kode akses 6 digit" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:10px;margin-top:8px"><button class="cta" style="width:100%;margin-top:10px" onclick="loadMyOrders()">Lihat Pesanan Saya</button><div id="myOrdersResult" style="margin-top:12px"></div></div></div>';
}

async function loadMyOrders(){
  const phone=(document.getElementById('ordersPhone')?.value||'').trim();
  const accessCode=(document.getElementById('ordersAccessCode')?.value||'').trim();
  const result=document.getElementById('myOrdersResult');
  lastCustomerPhone=phone;
  lastAccessCode=accessCode;
  if(!phone){result.innerHTML='<div class="empty">Masukkan nomor WhatsApp terlebih dahulu.</div>';return;}
  if(!/^\d{6}$/.test(accessCode)){result.innerHTML='<div class="empty">Masukkan kode akses 6 digit.</div>';return;}
  result.innerHTML='<div class="empty">Memuat pesanan...</div>';
  try{
    const rows=await sbFetch('/rest/v1/rpc/get_my_orders_secure',{
      method:'POST',
      body:JSON.stringify({p_customer_phone:phone,p_access_code:accessCode})
    });
    const orders=Array.isArray(rows)?rows:[];
    if(!orders.length){
      result.innerHTML='<div class="empty"><b>Pesanan tidak ditemukan.</b><br>Pastikan nomor WhatsApp dan kode akses sesuai saat checkout.</div>';
      return;
    }
    result.innerHTML='<div style="display:grid;gap:10px">'+orders.map(o=>{
      const st=orderStatusLabel[o.status]||o.status||'-';
      const pay=paymentStatusLabel[o.payment_status]||o.payment_status||'-';
      const courier=shippingCourierLabel(o.shipping_courier);
      const confirmed=o.shipping_confirmed !== false;
      let action='';
      if(o.status==='cancelled'){
        action='<button class="secondarybtn" style="width:100%;margin-top:10px" onclick="openMyOrder('+Number(o.id)+')">Lihat Status</button>';
      }else if(o.payment_status==='unpaid' && !confirmed){
        action='<button class="secondarybtn" style="width:100%;margin-top:10px" onclick="openMyOrder('+Number(o.id)+')">Menunggu Konfirmasi Ongkir</button>';
      }else if(o.payment_status==='unpaid' && confirmed){
        action='<button class="paybtn" style="width:100%;margin-top:10px" onclick="openMyOrder('+Number(o.id)+')">Bayar Sekarang</button>';
      }else{
        action='<button class="secondarybtn" style="width:100%;margin-top:10px" onclick="openMyOrder('+Number(o.id)+')">Lihat Status</button>';
      }
      return '<div style="padding:14px;border:1px solid var(--line);border-radius:14px;background:#fff"><div style="font-size:12px;color:#777">Pesanan #'+escapeHtml(o.id)+'</div><div style="font-weight:700;margin:4px 0">'+money(o.total_amount)+'</div><div style="font-size:13px">Status: <b>'+escapeHtml(st)+'</b></div><div style="font-size:12px;color:#777">Pembayaran: '+escapeHtml(pay)+'</div><div style="font-size:12px;color:#777;margin-top:3px">Kurir: '+escapeHtml(courier)+'</div>'+action+'</div>';
    }).join('')+'</div>';
  }catch(e){
    result.innerHTML='<div class="empty">Gagal memuat pesanan: '+escapeHtml(e.message||e)+'</div>';
  }
}

async function openMyOrder(orderId){
  const phone=(document.getElementById('ordersPhone')?.value||lastCustomerPhone||'').trim();
  const accessCode=(document.getElementById('ordersAccessCode')?.value||lastAccessCode||'').trim();
  if(!phone || !/^\d{6}$/.test(accessCode)){
    alert('Nomor WhatsApp dan kode akses 6 digit diperlukan.');
    return;
  }
  try{
    const rows=await sbFetch('/rest/v1/rpc/get_my_order_secure_detail',{
      method:'POST',
      body:JSON.stringify({
        p_order_id:Number(orderId),
        p_customer_phone:phone,
        p_access_code:accessCode
      })
    });
    const order=Array.isArray(rows)?rows[0]:rows;
    if(!order){alert('Pesanan tidak ditemukan atau akses tidak sesuai.');return;}
    lastCustomerPhone=phone;
    lastAccessCode=String(order.access_code||accessCode);
    lastOrder=order;
    if(order.status==='cancelled'){
      showOrderStatus(order.id,phone);
      return;
    }
    if(order.payment_status==='unpaid'){
      if(order.shipping_confirmed===false){
        showShippingPending(order);
      }else if(order.payment_token){
        showPayment(order);
      }else{
        alert('Token pembayaran tidak tersedia. Silakan hubungi admin Givitshop.');
      }
      return;
    }
    showOrderStatus(order.id,phone);
  }catch(e){
    alert('Gagal membuka pesanan: '+(e.message||e));
  }
}

async function showOrderStatus(orderId, phone){
  show('account');
  const section=document.getElementById('account');
  section.innerHTML='<div class="back" onclick="renderAccount()">‹ Kembali</div><div class="section"><div class="sectionhead"><h2>Status Pesanan</h2></div><div class="checkout"><input id="trackOrderId" inputmode="numeric" value="'+escapeHtml(orderId||'')+'" placeholder="Nomor pesanan, contoh 40" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:10px"><input id="trackPhone" inputmode="tel" value="'+escapeHtml(phone||'')+'" placeholder="Nomor WhatsApp saat checkout" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:10px;margin-top:10px"><button class="cta" style="width:100%;margin-top:10px" onclick="lookupMyOrder()">Cek Status Pesanan</button><div id="trackResult" style="margin-top:12px"></div></div></div>';
}

async function lookupMyOrder(){
  const orderId=(document.getElementById('trackOrderId')?.value||'').trim();
  const phone=(document.getElementById('trackPhone')?.value||'').trim();
  const result=document.getElementById('trackResult');
  if(!orderId || !phone){result.innerHTML='<div class="empty">Isi nomor pesanan dan nomor WhatsApp terlebih dahulu.</div>';return;}
  result.innerHTML='<div class="empty">Memeriksa pesanan...</div>';
  try{
    const rows=await sbFetch('/rest/v1/rpc/get_my_order',{
      method:'POST',
      body:JSON.stringify({p_order_id:Number(orderId),p_customer_phone:phone})
    });
    const o=Array.isArray(rows)?rows[0]:rows;
    if(!o){result.innerHTML='<div class="empty"><b>Pesanan tidak ditemukan.</b><br>Pastikan nomor pesanan dan nomor WhatsApp sesuai saat checkout.</div>';return;}
    const status=orderStatusLabel[o.status]||o.status||'-';
    const payment=paymentStatusLabel[o.payment_status]||o.payment_status||'-';
    const statusClass=o.status==='cancelled'?'background:#fff0f0;color:#b42318':'background:#fff4f7;color:#c53e61';
    const steps=[
      ['🛒','Pesanan dibuat','pending'],
      ['💳','Pembayaran','payment'],
      ['📦','Diproses','processing'],
      ['🚚','Dikirim','shipped'],
      ['✅','Selesai','completed']
    ];
    const orderProgress={pending:1,processing:3,shipped:4,completed:5,cancelled:0};
    const progress=orderProgress[o.status]||1;
    const timeline=o.status==='cancelled'
      ? '<div style="margin-top:14px;padding:14px;border-radius:14px;background:#fff0f0;color:#b42318"><b>❌ Pesanan dibatalkan</b><div style="font-size:11px;margin-top:4px">Pesanan ini tidak dilanjutkan ke proses berikutnya.</div></div>'
      : '<div style="margin-top:16px;padding:14px;border:1px solid var(--line);border-radius:14px;background:#fff"><b>Perjalanan Pesanan</b><div style="margin-top:12px">'+steps.map((st,i)=>{const active=(st[2]==='payment'?((o.payment_status==='awaiting_verification'||o.payment_status==='paid')?2:1):(i+1));const done=progress>=i+1;const isCurrent=(o.status==='pending'&&i===0)||(st[2]==='payment'&&o.status==='pending'&&o.payment_status!=='unpaid')||(st[2]===o.status);return '<div style="display:flex;align-items:center;gap:10px;padding:7px 0"><div style="width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:'+(done?'#e85b7a':'#f3eef0')+';color:'+(done?'#fff':'#999')+'">'+st[0]+'</div><div style="font-size:12px;font-weight:'+(done||isCurrent?'700':'400')+';color:'+(done||isCurrent?'#26232a':'#999')+'">'+st[1]+'</div></div>'}).join('')+'</div></div>';
    result.innerHTML='<div style="border:1px solid var(--line);border-radius:16px;padding:16px;background:#fff"><div style="font-size:12px;color:#777">Pesanan #'+escapeHtml(o.id)+'</div><h3 style="margin:6px 0 14px">'+escapeHtml(o.customer_name||'')+'</h3><div style="padding:12px;border-radius:12px;'+statusClass+'"><b>Status pesanan: '+escapeHtml(status)+'</b></div>'+timeline+'<div style="margin-top:10px;padding:12px;border-radius:12px;background:#faf8f9">Status pembayaran: <b>'+escapeHtml(payment)+'</b><br>Total: <b>'+money(o.total_amount)+'</b></div><div style="font-size:11px;color:#777;margin-top:10px">Terakhir diperbarui dari sistem Givitshop.</div></div>';
  }catch(e){
    result.innerHTML='<div class="empty">Gagal memeriksa pesanan: '+escapeHtml(e.message||e)+'</div>';
  }
}

function renderAccount(){
  document.getElementById('account').innerHTML='<div class="back">Akun Saya</div><div class="section"><div class="admin" style="background:linear-gradient(135deg,#e85b7a,#c53e61)"><h2>Givitshop</h2><div>Belanja dan pesananmu tersimpan di sistem.</div></div><div class="sectionhead"><h2>Menu</h2></div><div style="display:grid;gap:10px"><button onclick="showMyOrders(lastCustomerPhone, lastAccessCode)" style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">📦 Pesanan Saya <span style="float:right">›</span></button><button style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">📍 Alamat Saya <span style="float:right">›</span></button><button style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">🎟️ Voucher Saya <span style="float:right">›</span></button><button style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">♡ Wishlist <span style="float:right">›</span></button><button style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">⭐ Ulasan Saya <span style="float:right">›</span></button><button style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">💬 Pusat Bantuan <span style="float:right">›</span></button></div></div>';
}

loadProducts();
