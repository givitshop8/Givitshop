-- Givitshop: payment gate for GrabExpress / Maxim
-- Jalankan di Supabase SQL Editor setelah fitur ongkir manual aktif.

drop function if exists public.get_my_orders_secure(text);

create or replace function public.get_my_orders_secure(
  p_customer_phone text,
  p_access_code text
)
returns table (
  id bigint,
  customer_name text,
  total_amount numeric,
  status text,
  payment_status text,
  created_at timestamptz,
  shipping_courier text,
  shipping_service text,
  shipping_cost numeric,
  shipping_confirmed boolean
)
language sql
security definer
set search_path = public
as $$
  select
    o.id,
    o.customer_name,
    o.total_amount,
    o.status,
    o.payment_status,
    o.created_at,
    o.shipping_courier,
    o.shipping_service,
    o.shipping_cost,
    o.shipping_confirmed
  from public.orders o
  where regexp_replace(o.customer_phone, '[^0-9]', '', 'g')
      = regexp_replace(p_customer_phone, '[^0-9]', '', 'g')
    and o.access_code = p_access_code
  order by o.created_at desc;
$$;

revoke all on function public.get_my_orders_secure(text,text)
from public;

grant execute on function public.get_my_orders_secure(text,text)
to anon, authenticated;


create or replace function public.get_my_order_secure_detail(
  p_order_id bigint,
  p_customer_phone text,
  p_access_code text
)
returns table (
  id bigint,
  customer_name text,
  total_amount numeric,
  status text,
  payment_status text,
  created_at timestamptz,
  shipping_courier text,
  shipping_service text,
  shipping_cost numeric,
  shipping_confirmed boolean,
  payment_token text,
  access_code text
)
language sql
security definer
set search_path = public
as $$
  select
    o.id,
    o.customer_name,
    o.total_amount,
    o.status,
    o.payment_status,
    o.created_at,
    o.shipping_courier,
    o.shipping_service,
    o.shipping_cost,
    o.shipping_confirmed,
    case
      when coalesce(o.shipping_confirmed, true) = true
           and o.payment_status = 'unpaid'
      then o.payment_token
      else null
    end as payment_token,
    o.access_code
  from public.orders o
  where o.id = p_order_id
    and regexp_replace(o.customer_phone, '[^0-9]', '', 'g')
        = regexp_replace(p_customer_phone, '[^0-9]', '', 'g')
    and o.access_code = p_access_code
  limit 1;
$$;

revoke all on function public.get_my_order_secure_detail(bigint,text,text)
from public;

grant execute on function public.get_my_order_secure_detail(bigint,text,text)
to anon, authenticated;
