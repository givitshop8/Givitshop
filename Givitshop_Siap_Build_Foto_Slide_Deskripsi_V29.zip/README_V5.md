# Givitshop Customer V5

V5 dibuat berdasarkan ZIP V4 yang diberikan. Perbaikan antarmuka:
- Foto detail produk memakai contain dan area gambar responsif agar gambar tidak terpotong.
- Galeri detail produk mendukung swipe horizontal pada foto yang tersedia dari image_url, images, image_urls, serta foto varian.
- Deskripsi menggunakan jarak paragraf lebih rapat dan mempertahankan baris baru.
- Label harga pada detail tetap menampilkan rentang harga jika ada beberapa harga varian/opsi.

Workflow `.github/workflows/main.yml` diarahkan untuk mengekstrak `Givitshop_Siap_Build_Foto_Slide_Deskripsi_V5.zip`.
