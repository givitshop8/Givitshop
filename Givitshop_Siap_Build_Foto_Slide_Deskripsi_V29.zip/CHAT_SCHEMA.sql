-- Givitshop Chat Pembeli <-> Admin
-- Jalankan seluruh file ini di Supabase SQL Editor.
-- Chat pembeli hanya dapat diakses lewat RPC yang memverifikasi order_id + nomor HP + access_code.
-- Admin harus memiliki app_metadata.role = 'admin'.

create extension if not exists pgcrypto;

create table if not exists public.chat_conversations (
  id uuid primary key default gen_random_uuid(),
  order_id bigint not null unique references public.orders(id) on delete cascade,
  customer_phone text not null,
  last_message_preview text,
  last_message_at timestamptz not null default now(),
  last_sender_role text check (last_sender_role in ('customer','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.chat_conversations(id) on delete cascade,
  sender_role text not null check (sender_role in ('customer','admin')),
  message text not null check (char_length(trim(message)) between 1 and 2000),
  created_at timestamptz not null default now()
);

create index if not exists chat_messages_conversation_created_idx
  on public.chat_messages(conversation_id, created_at);

alter table public.chat_conversations enable row level security;
alter table public.chat_messages enable row level security;

revoke all on public.chat_conversations from anon, authenticated;
revoke all on public.chat_messages from anon, authenticated;
grant select, insert, update on public.chat_conversations to authenticated;
grant select, insert on public.chat_messages to authenticated;

drop policy if exists "Givit admins manage conversations" on public.chat_conversations;
create policy "Givit admins manage conversations"
on public.chat_conversations for all to authenticated
using ((auth.jwt()->'app_metadata'->>'role') = 'admin')
with check ((auth.jwt()->'app_metadata'->>'role') = 'admin');

drop policy if exists "Givit admins manage messages" on public.chat_messages;
create policy "Givit admins manage messages"
on public.chat_messages for all to authenticated
using ((auth.jwt()->'app_metadata'->>'role') = 'admin')
with check ((auth.jwt()->'app_metadata'->>'role') = 'admin');

create or replace function public.customer_get_chat_messages(
  p_order_id bigint, p_phone text, p_access_code text
)
returns table(id uuid, sender_role text, message text, created_at timestamptz)
language plpgsql security definer
set search_path = public, pg_temp
as $$
declare
  v_order public.orders%rowtype;
  v_conversation_id uuid;
begin
  select * into v_order from public.orders o
  where o.id = p_order_id
    and regexp_replace(coalesce(o.customer_phone,''), '\D', '', 'g') = regexp_replace(coalesce(p_phone,''), '\D', '', 'g')
    and trim(coalesce(o.access_code::text,'')) = trim(coalesce(p_access_code,''));
  if not found then
    raise exception 'Nomor pesanan, WhatsApp, atau kode akses tidak cocok.';
  end if;

  insert into public.chat_conversations(order_id, customer_phone, last_message_preview, last_message_at)
  values (v_order.id, v_order.customer_phone, 'Percakapan dimulai', now())
  on conflict (order_id) do update set customer_phone = excluded.customer_phone
  returning id into v_conversation_id;

  return query
    select m.id, m.sender_role, m.message, m.created_at
    from public.chat_messages m
    where m.conversation_id = v_conversation_id
    order by m.created_at asc;
end;
$$;

create or replace function public.customer_send_chat_message(
  p_order_id bigint, p_phone text, p_access_code text, p_message text
)
returns uuid
language plpgsql security definer
set search_path = public, pg_temp
as $$
declare
  v_order public.orders%rowtype;
  v_conversation_id uuid;
  v_message_id uuid;
  v_message text := trim(coalesce(p_message,''));
begin
  if char_length(v_message) < 1 or char_length(v_message) > 2000 then
    raise exception 'Pesan harus berisi 1–2000 karakter.';
  end if;

  select * into v_order from public.orders o
  where o.id = p_order_id
    and regexp_replace(coalesce(o.customer_phone,''), '\D', '', 'g') = regexp_replace(coalesce(p_phone,''), '\D', '', 'g')
    and trim(coalesce(o.access_code::text,'')) = trim(coalesce(p_access_code,''));
  if not found then
    raise exception 'Nomor pesanan, WhatsApp, atau kode akses tidak cocok.';
  end if;

  insert into public.chat_conversations(order_id, customer_phone, last_message_preview, last_message_at, last_sender_role)
  values (v_order.id, v_order.customer_phone, left(v_message,160), now(), 'customer')
  on conflict (order_id) do update
    set customer_phone = excluded.customer_phone,
        last_message_preview = excluded.last_message_preview,
        last_message_at = now(),
        last_sender_role = 'customer'
  returning id into v_conversation_id;

  insert into public.chat_messages(conversation_id, sender_role, message)
  values (v_conversation_id, 'customer', v_message)
  returning id into v_message_id;

  return v_message_id;
end;
$$;

revoke all on function public.customer_get_chat_messages(bigint,text,text) from public;
revoke all on function public.customer_send_chat_message(bigint,text,text,text) from public;
grant execute on function public.customer_get_chat_messages(bigint,text,text) to anon, authenticated;
grant execute on function public.customer_send_chat_message(bigint,text,text,text) to anon, authenticated;

-- Setelah menjalankan SQL:
-- Supabase Dashboard > Authentication > Users > pilih akun admin
-- Edit app_metadata menjadi {"role":"admin"} (jangan menaruh role admin di user_metadata).
-- Logout lalu login ulang di panel admin agar JWT baru memuat role tersebut.
