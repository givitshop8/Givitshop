
/* ===== GIVITSHOP + SUPABASE =====
   Isi SUPABASE_ANON_KEY dengan Publishable/anon key dari:
   Supabase > Project Settings > API.
   JANGAN gunakan service_role key di aplikasi.
*/
const SUPABASE_URL = 'https://oaojkkhvscbufpakunrs.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_jeoQMVZMgtnJeUR9tsq8tg_owYrhU-S';

let products = [];
let cart = [];
let currentFilter = 'Semua';
let lastOrder = null;
let lastCustomerPhone = '';
let lastAccessCode = '';
const paymentToken = () => (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : String(Date.now())+'-'+Math.random().toString(36).slice(2));

const money = n => new Intl.NumberFormat('id-ID',{
  style:'currency',currency:'IDR',maximumFractionDigits:0
}).format(Number(n)||0);

async function sbFetch(path, options={}) {
  if (!SUPABASE_ANON_KEY || SUPABASE_ANON_KEY.includes('GANTI_DENGAN')) {
    throw new Error('API key Supabase belum diisi.');
  }
  const headers = Object.assign({
    'apikey': SUPABASE_ANON_KEY,
    'Authorization': 'Bearer ' + SUPABASE_ANON_KEY,
    'Content-Type': 'application/json'
  }, options.headers || {});
  const res = await fetch(SUPABASE_URL + path, Object.assign({}, options, {headers}));
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch(e) {}
  if (!res.ok) throw new Error((data && (data.message || data.hint || data.error)) || text || ('HTTP '+res.status));
  return data;
}

function productType(p) {
  const s = (p.name || '').toLowerCase();
  return /serum|sunscreen|toner|spray|shampoo|conditioner|lip|cream tube|bottle/.test(s) ? 'bottle' : 'jar';
}

function productImage(p, cls='') {
  return p.image_url
    ? `<img class="productimg ${cls}" src="${p.image_url}" alt="${escapeHtml(p.name)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><div class="${productType(p)} fallback"></div>`
    : `<div class="${productType(p)}"></div>`;
}

function escapeHtml(s='') {
  return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}

async function loadProducts() {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '<div class="empty">Memuat produk...</div>';
  try {
    const data = await sbFetch('/rest/v1/products?select=*&is_active=eq.true&order=created_at.desc');
    products = Array.isArray(data) ? data : [];
    renderProducts();
  } catch (e) {
    console.error(e);
    grid.innerHTML = `<div class="empty"><h3>Produk belum dapat dimuat</h3><p style="font-size:11px">${escapeHtml(e.message)}</p><button class="cta" onclick="loadProducts()">Coba Lagi</button></div>`;
  }
}

function renderProducts() {
  const input = document.getElementById('search');
  const q = (input ? input.value : '').toLowerCase();
  const list = products.filter(p =>
    (currentFilter==='Semua' || (p.category||'')===currentFilter) &&
    (`${p.name||''} ${p.brand||''} ${p.category||''}`.toLowerCase().includes(q))
  );
  document.getElementById('productGrid').innerHTML =
    list.map(p => `<article class="product">
      <div class="pic" onclick="detail('${p.id}')">
        <button class="heart" onclick="event.stopPropagation()">♡</button>
        ${productImage(p)}
      </div>
      <div class="pbody">
        <div class="pname">${escapeHtml(p.name)}</div>
        <div style="font-size:10px;color:#777">${escapeHtml(p.brand||p.category||'')}</div>
        <div class="rating">★ 4.9 · Stok ${Number(p.stock)||0}</div>
        <div class="price">${money(p.price)}</div>
        <button class="add" onclick="add('${p.id}')">+ Keranjang</button>
      </div>
    </article>`).join('') || '<div class="empty">Produk tidak ditemukan.</div>';
}

function filterCat(c) {
  currentFilter=c;
  document.querySelectorAll('.chip').forEach(x=>x.classList.remove('active'));
  renderProducts();
}

function detail(id) {
  const p=products.find(x=>x.id===id);
  if(!p) return;
  document.getElementById('detail').innerHTML =
    `<div class="back" onclick="show('home')">‹ Kembali</div>
     <div class="detailpic">${productImage(p)}</div>
     <div class="detail">
       <div style="font-size:11px;color:#777">${escapeHtml(p.brand||p.category||'')}</div>
       <h1>${escapeHtml(p.name)}</h1>
       <div class="rating">★ 4.9 · Stok ${Number(p.stock)||0}</div>
       <div class="price" style="font-size:22px">${money(p.price)}</div>
       <p class="desc">${escapeHtml(p.description||'Produk pilihan Givitshop. Informasi produk dapat diperbarui dari database.')}</p>
       <p class="desc">✓ Produk original &nbsp; ✓ Kemasan aman &nbsp; ✓ Stok tersedia</p>
     </div>
     <div class="buybar">
       <div class="pricebox">${money(p.price)}</div>
       <button class="primary" onclick="add('${p.id}');show('cart')">+ Keranjang</button>
     </div>`;
  show('detail');
}

function add(id) {
  const p=products.find(x=>x.id===id);
  if(!p) return;
  if(Number(p.stock)<=0){alert('Stok produk sedang habis.');return;}
  const x=cart.find(i=>i.id===id);
  if(x){
    if(x.qty >= Number(p.stock)){alert('Jumlah melebihi stok.');return;}
    x.qty++;
  } else cart.push({id,qty:1});
  renderCart();
}

function renderCart() {
  const c=document.getElementById('cart');
  if(!cart.length){
    c.innerHTML='<div class="back">Keranjang</div><div class="empty">🛒<h3>Keranjang masih kosong</h3><p>Yuk pilih produk favoritmu.</p><button class="cta" onclick="show(\'home\')">Mulai Belanja</button></div>';
    return;
  }
  const total=cart.reduce((s,i)=>s+(Number(products.find(p=>p.id===i.id)?.price)||0)*i.qty,0);
  c.innerHTML='<div class="back">Keranjang Belanja</div><div class="section">'+
    cart.map(i=>{
      const p=products.find(x=>x.id===i.id); if(!p) return '';
      return `<div class="cartrow"><div class="thumb">${productImage(p)}</div>
        <div class="cartinfo"><b style="font-size:12px">${escapeHtml(p.name)}</b>
        <div class="price">${money(p.price)}</div>
        <div class="qty"><button onclick="changeQty('${p.id}',-1)">−</button><span>${i.qty}</span><button onclick="changeQty('${p.id}',1)">+</button></div></div></div>`;
    }).join('')+
    '</div><div class="checkout"><div class="checkoutrow"><span>Subtotal</span><b>'+money(total)+'</b></div><div class="checkoutrow"><span>Ongkir</span><span>Rp15.000</span></div><hr><div class="checkoutrow"><b>Total</b><span class="total">'+money(total+15000)+'</span></div><button class="cta" style="width:100%;margin-top:10px" onclick="showCheckout()">Checkout</button></div>';
}

function changeQty(id,d) {
  const x=cart.find(i=>i.id===id); if(!x) return;
  const p=products.find(i=>i.id===id);
  x.qty+=d;
  if(x.qty>Number(p.stock)) x.qty=Number(p.stock);
  if(x.qty<=0) cart=cart.filter(i=>i.id!==id);
  renderCart();
}

function showCheckout() {
  if(!cart.length) return;
  const total=cart.reduce((s,i)=>s+(Number(products.find(p=>p.id===i.id)?.price)||0)*i.qty,0)+15000;
  document.getElementById('checkout').innerHTML=
    `<div class="back" onclick="show('cart')">‹ Checkout</div>
     <div class="checkout">
       <b>Data Pengiriman</b>
       <input id="custName" placeholder="Nama lengkap" style="width:100%;padding:12px;margin-top:10px;border:1px solid var(--line);border-radius:10px">
       <input id="custPhone" placeholder="Nomor WhatsApp" style="width:100%;padding:12px;margin-top:8px;border:1px solid var(--line);border-radius:10px">
       <textarea id="custAddress" placeholder="Alamat lengkap pengiriman" style="width:100%;height:90px;padding:12px;margin-top:8px;border:1px solid var(--line);border-radius:10px;resize:none"></textarea>
       <hr><b>Kurir</b><p style="font-size:12px">JNE Regular — Rp15.000</p>
       <hr><b>Metode Pembayaran</b><div style="margin-top:8px;padding:12px;border:1px solid var(--pink);border-radius:12px;background:#fff7f9"><b>▣ QRIS GIVIT SHOP</b><div style="font-size:11px;color:#777;margin-top:4px">Bayar dengan aplikasi bank atau e-wallet yang mendukung QRIS.</div></div>
       <div class="checkoutrow"><b>Total Pesanan</b><span class="total">${money(total)}</span></div>
       <button id="orderBtn" type="button" class="cta" style="width:100%;margin-top:10px" onclick="placeOrder()">Buat Pesanan</button><div id="orderError" style="display:none;margin-top:10px;padding:10px;border-radius:10px;background:#fff0f0;color:#b42318;font-size:11px"></div>
     </div>`;
  show('checkout');
}

async function placeOrder() {
  const customer_name=document.getElementById('custName').value.trim();
  const customer_phone=document.getElementById('custPhone').value.trim();
  const customer_address=document.getElementById('custAddress').value.trim();
  if(!customer_name || !customer_phone || !customer_address){alert('Lengkapi nama, nomor WhatsApp, dan alamat.');return;}
  const btn=document.getElementById('orderBtn'); btn.disabled=true; btn.textContent='Menyimpan pesanan...';
  try {
    const items=cart.map(i=>{
      const p=products.find(x=>x.id===i.id);
      return {product_id:p.id,product_name:p.name,price:Number(p.price),quantity:i.qty,subtotal:Number(p.price)*i.qty};
    });
    const total=items.reduce((s,i)=>s+i.subtotal,0)+15000;
    const token=paymentToken();
    const order=await sbFetch('/rest/v1/rpc/place_order',{
      method:'POST',
      body:JSON.stringify({
        p_customer_name:customer_name,
        p_customer_phone:customer_phone,
        p_customer_address:customer_address,
        p_payment_token:token,
        p_items:items.map(i=>({product_id:i.product_id,quantity:i.quantity}))
      })
    });
    if(!order || !order.id) throw new Error('Order tidak mengembalikan ID.');

    // Ambil kode akses 6 digit dari database setelah order berhasil dibuat.
    try {
      const codeResult=await sbFetch('/rest/v1/rpc/get_order_access_code',{
        method:'POST',
        body:JSON.stringify({p_order_id:order.id,p_payment_token:token})
      });
      const accessCode=typeof codeResult==='string'
        ? codeResult
        : (Array.isArray(codeResult) ? codeResult[0] : codeResult);
      order.access_code=String(accessCode||'');
    } catch(e) {
      order.access_code='';
    }

    lastOrder=order;
    lastCustomerPhone=customer_phone;
    lastAccessCode=order.access_code||'';
    cart=[];
    renderCart();
    showPayment(order);

  } catch(e) {
    const msg='Pesanan gagal disimpan: '+(e && e.message ? e.message : e);
    const err=document.getElementById('orderError');
    if(err){err.style.display='block';err.textContent=msg;}
    btn.disabled=false; btn.textContent='Buat Pesanan';
  }
}


function showPayment(order){
  const total=Number(order.total_amount)||0;
  document.getElementById('orders').innerHTML=
    `<div class="back" onclick="show('home')">‹ Kembali ke Beranda</div>
     <div class="qriscard">
       <div style="font-size:12px;color:#777">Pesanan #${order.id}</div>
       <h2 style="margin:6px 0">Pembayaran QRIS</h2>
       <div class="qrisamount">${money(total)}</div>
       <div style="margin:12px 0;padding:12px;border:2px dashed var(--pink);border-radius:12px;background:#fff7f9;text-align:center">
         <div style="font-size:11px;color:#777">KODE AKSES PESANAN</div>
         <div style="font-size:25px;font-weight:800;letter-spacing:4px;margin-top:3px">${escapeHtml(order.access_code||'-')}</div>
         <div style="font-size:10px;color:#777;margin-top:4px">Simpan kode ini untuk melihat Pesanan Saya.</div>
       </div>
       <div class="qrisnote">Bayar tepat sebesar <b>${money(total)}</b> dengan scan QRIS di bawah.</div>
       <img class="qrisimg" src="qris_givitshop.png" alt="QRIS GIVIT SHOP">
       <div class="qrisnote">GIVIT SHOP • NMID ID1025372324331</div>
       <div class="qrisstatus">
         <b>Langkah pembayaran</b><br>
         1. Buka aplikasi bank/e-wallet yang mendukung QRIS.<br>
         2. Scan QRIS GIVIT SHOP.<br>
         3. Masukkan nominal <b>${money(total)}</b>.<br>
         4. Selesaikan pembayaran, lalu tekan tombol di bawah.
       </div>
       <button class="paybtn" onclick="confirmPayment(${order.id},'${escapeHtml(order.payment_token||'')}')">Saya sudah bayar</button>
       <button class="secondarybtn" onclick="show('home')">Bayar nanti</button>
     </div>`;
  show('orders');
}

async function confirmPayment(orderId, token){
  if(!token){alert('Token pembayaran tidak tersedia. Silakan buat pesanan baru.');return;}
  try{
    await sbFetch('/rest/v1/rpc/confirm_order_payment',{
      method:'POST',
      body:JSON.stringify({p_order_id:orderId,p_payment_token:token})
    });
    document.getElementById('orders').innerHTML=
      `<div class="back" onclick="show('home')">‹ Kembali ke Beranda</div>
       <div class="qriscard">
         <div style="font-size:38px">✓</div>
         <h2>Pembayaran dikonfirmasi</h2>
         <p style="font-size:12px;color:#6f6a70">Pesanan #${orderId} sudah ditandai <b>Menunggu verifikasi</b>.</p>
         <div style="margin:12px 0;padding:12px;border:2px dashed var(--pink);border-radius:12px;background:#fff7f9;text-align:center">
           <div style="font-size:11px;color:#777">KODE AKSES PESANAN</div>
           <div style="font-size:25px;font-weight:800;letter-spacing:4px;margin-top:3px">${escapeHtml(lastAccessCode||'-')}</div>
           <div style="font-size:10px;color:#777;margin-top:4px">Simpan kode ini untuk melihat Pesanan Saya.</div>
         </div>
         <div class="qrisstatus">Admin Givitshop akan memeriksa pembayaran sebelum pesanan diproses.</div>
         <button class="paybtn" onclick="showOrderStatus(${orderId},lastCustomerPhone)">Lihat Status Pesanan</button>
          <button class="secondarybtn" onclick="show('home')">Kembali ke Beranda</button>
       </div>`;
  }catch(e){
    alert('Konfirmasi pembayaran gagal: '+e.message);
  }
}

function show(v){
  document.querySelectorAll('.view').forEach(x=>x.classList.remove('active'));
  document.getElementById(v).classList.add('active');
  document.querySelectorAll('.nav').forEach(x=>x.classList.toggle('active',x.dataset.v===v));
  if(v==='cart')renderCart();
  if(v==='account')renderAccount();
  scrollTo(0,0);
}


const orderStatusLabel = {
  pending: 'Menunggu',
  processing: 'Diproses',
  shipped: 'Dikirim',
  completed: 'Selesai',
  cancelled: 'Dibatalkan'
};

const paymentStatusLabel = {
  unpaid: 'Belum dibayar',
  awaiting_verification: 'Menunggu verifikasi',
  paid: 'Sudah dibayar'
};


async function showMyOrders(phone='', accessCode=''){
  show('account');
  const section=document.getElementById('account');
  section.innerHTML='<div class="back" onclick="renderAccount()">‹ Kembali</div><div class="section"><div class="sectionhead"><h2>Pesanan Saya</h2></div><div class="checkout"><input id="ordersPhone" inputmode="tel" value="'+escapeHtml(phone||'')+'" placeholder="Nomor WhatsApp saat checkout" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:10px"><input id="ordersAccessCode" inputmode="numeric" maxlength="6" value="'+escapeHtml(accessCode||'')+'" placeholder="Kode akses 6 digit" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:10px;margin-top:8px"><button class="cta" style="width:100%;margin-top:10px" onclick="loadMyOrders()">Lihat Pesanan Saya</button><div id="myOrdersResult" style="margin-top:12px"></div></div></div>';
}

async function loadMyOrders(){
  const phone=(document.getElementById('ordersPhone')?.value||'').trim();
  const accessCode=(document.getElementById('ordersAccessCode')?.value||'').trim();
  const result=document.getElementById('myOrdersResult');
  lastCustomerPhone=phone;
  lastAccessCode=accessCode;
  if(!phone){result.innerHTML='<div class="empty">Masukkan nomor WhatsApp terlebih dahulu.</div>';return;}
  if(!/^\d{6}$/.test(accessCode)){result.innerHTML='<div class="empty">Masukkan kode akses 6 digit.</div>';return;}
  result.innerHTML='<div class="empty">Memuat pesanan...</div>';
  try{
    const rows=await sbFetch('/rest/v1/rpc/get_my_orders_secure',{
      method:'POST',
      body:JSON.stringify({p_customer_phone:phone,p_access_code:accessCode})
    });
    const orders=Array.isArray(rows)?rows:[];
    if(!orders.length){
      result.innerHTML='<div class="empty"><b>Pesanan tidak ditemukan.</b><br>Pastikan nomor WhatsApp dan kode akses sesuai saat checkout.</div>';
      return;
    }
    result.innerHTML='<div style="display:grid;gap:10px">'+orders.map(o=>{
      const st=orderStatusLabel[o.status]||o.status||'-';
      const pay=paymentStatusLabel[o.payment_status]||o.payment_status||'-';
      return '<button onclick="showOrderStatus('+Number(o.id)+',\''+String(phone).replace(/\\/g,'\\\\').replace(/'/g,"\\'")+'\')" style="text-align:left;padding:14px;border:1px solid var(--line);border-radius:14px;background:#fff"><div style="font-size:12px;color:#777">Pesanan #'+escapeHtml(o.id)+'</div><div style="font-weight:700;margin:4px 0">'+money(o.total_amount)+'</div><div style="font-size:13px">Status: <b>'+escapeHtml(st)+'</b></div><div style="font-size:12px;color:#777">Pembayaran: '+escapeHtml(pay)+'</div></button>';
    }).join('')+'</div>';
  }catch(e){
    result.innerHTML='<div class="empty">Gagal memuat pesanan: '+escapeHtml(e.message||e)+'</div>';
  }
}

async function showOrderStatus(orderId, phone){
  show('account');
  const section=document.getElementById('account');
  section.innerHTML='<div class="back" onclick="renderAccount()">‹ Kembali</div><div class="section"><div class="sectionhead"><h2>Status Pesanan</h2></div><div class="checkout"><input id="trackOrderId" inputmode="numeric" value="'+escapeHtml(orderId||'')+'" placeholder="Nomor pesanan, contoh 40" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:10px"><input id="trackPhone" inputmode="tel" value="'+escapeHtml(phone||'')+'" placeholder="Nomor WhatsApp saat checkout" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:10px;margin-top:10px"><button class="cta" style="width:100%;margin-top:10px" onclick="lookupMyOrder()">Cek Status Pesanan</button><div id="trackResult" style="margin-top:12px"></div></div></div>';
}

async function lookupMyOrder(){
  const orderId=(document.getElementById('trackOrderId')?.value||'').trim();
  const phone=(document.getElementById('trackPhone')?.value||'').trim();
  const result=document.getElementById('trackResult');
  if(!orderId || !phone){result.innerHTML='<div class="empty">Isi nomor pesanan dan nomor WhatsApp terlebih dahulu.</div>';return;}
  result.innerHTML='<div class="empty">Memeriksa pesanan...</div>';
  try{
    const rows=await sbFetch('/rest/v1/rpc/get_my_order',{
      method:'POST',
      body:JSON.stringify({p_order_id:Number(orderId),p_customer_phone:phone})
    });
    const o=Array.isArray(rows)?rows[0]:rows;
    if(!o){result.innerHTML='<div class="empty"><b>Pesanan tidak ditemukan.</b><br>Pastikan nomor pesanan dan nomor WhatsApp sesuai saat checkout.</div>';return;}
    const status=orderStatusLabel[o.status]||o.status||'-';
    const payment=paymentStatusLabel[o.payment_status]||o.payment_status||'-';
    const statusClass=o.status==='cancelled'?'background:#fff0f0;color:#b42318':'background:#fff4f7;color:#c53e61';
    const steps=[
      ['🛒','Pesanan dibuat','pending'],
      ['💳','Pembayaran','payment'],
      ['📦','Diproses','processing'],
      ['🚚','Dikirim','shipped'],
      ['✅','Selesai','completed']
    ];
    const orderProgress={pending:1,processing:3,shipped:4,completed:5,cancelled:0};
    const progress=orderProgress[o.status]||1;
    const timeline=o.status==='cancelled'
      ? '<div style="margin-top:14px;padding:14px;border-radius:14px;background:#fff0f0;color:#b42318"><b>❌ Pesanan dibatalkan</b><div style="font-size:11px;margin-top:4px">Pesanan ini tidak dilanjutkan ke proses berikutnya.</div></div>'
      : '<div style="margin-top:16px;padding:14px;border:1px solid var(--line);border-radius:14px;background:#fff"><b>Perjalanan Pesanan</b><div style="margin-top:12px">'+steps.map((st,i)=>{const active=(st[2]==='payment'?((o.payment_status==='awaiting_verification'||o.payment_status==='paid')?2:1):(i+1));const done=progress>=i+1;const isCurrent=(o.status==='pending'&&i===0)||(st[2]==='payment'&&o.status==='pending'&&o.payment_status!=='unpaid')||(st[2]===o.status);return '<div style="display:flex;align-items:center;gap:10px;padding:7px 0"><div style="width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:'+(done?'#e85b7a':'#f3eef0')+';color:'+(done?'#fff':'#999')+'">'+st[0]+'</div><div style="font-size:12px;font-weight:'+(done||isCurrent?'700':'400')+';color:'+(done||isCurrent?'#26232a':'#999')+'">'+st[1]+'</div></div>'}).join('')+'</div></div>';
    result.innerHTML='<div style="border:1px solid var(--line);border-radius:16px;padding:16px;background:#fff"><div style="font-size:12px;color:#777">Pesanan #'+escapeHtml(o.id)+'</div><h3 style="margin:6px 0 14px">'+escapeHtml(o.customer_name||'')+'</h3><div style="padding:12px;border-radius:12px;'+statusClass+'"><b>Status pesanan: '+escapeHtml(status)+'</b></div>'+timeline+'<div style="margin-top:10px;padding:12px;border-radius:12px;background:#faf8f9">Status pembayaran: <b>'+escapeHtml(payment)+'</b><br>Total: <b>'+money(o.total_amount)+'</b></div><div style="font-size:11px;color:#777;margin-top:10px">Terakhir diperbarui dari sistem Givitshop.</div></div>';
  }catch(e){
    result.innerHTML='<div class="empty">Gagal memeriksa pesanan: '+escapeHtml(e.message||e)+'</div>';
  }
}

function renderAccount(){
  document.getElementById('account').innerHTML='<div class="back">Akun Saya</div><div class="section"><div class="admin" style="background:linear-gradient(135deg,#e85b7a,#c53e61)"><h2>Givitshop</h2><div>Belanja dan pesananmu tersimpan di sistem.</div></div><div class="sectionhead"><h2>Menu</h2></div><div style="display:grid;gap:10px"><button onclick="showMyOrders(lastCustomerPhone, lastAccessCode)" style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">📦 Pesanan Saya <span style="float:right">›</span></button><button style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">📍 Alamat Saya <span style="float:right">›</span></button><button style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">🎟️ Voucher Saya <span style="float:right">›</span></button><button style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">♡ Wishlist <span style="float:right">›</span></button><button style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">⭐ Ulasan Saya <span style="float:right">›</span></button><button style="padding:15px;text-align:left;border:1px solid var(--line);border-radius:14px;background:#fff">💬 Pusat Bantuan <span style="float:right">›</span></button></div></div>';
}

loadProducts();
