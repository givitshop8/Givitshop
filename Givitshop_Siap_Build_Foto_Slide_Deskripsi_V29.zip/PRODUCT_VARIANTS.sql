-- Givitshop: multi-item variants + size options
-- Run once in Supabase SQL Editor.

create table if not exists public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  name text not null,
  price numeric,
  stock integer not null default 0,
  weight_grams integer not null default 100,
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint product_variants_stock_check check (stock >= 0),
  constraint product_variants_weight_check check (weight_grams >= 1 and weight_grams <= 1000)
);

create table if not exists public.product_sizes (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  name text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.order_items add column if not exists variant_id uuid references public.product_variants(id) on delete set null;
alter table public.order_items add column if not exists variant_name text;
alter table public.order_items add column if not exists size_name text;

alter table public.product_variants enable row level security;
alter table public.product_sizes enable row level security;

drop policy if exists "Public can view active product variants" on public.product_variants;
create policy "Public can view active product variants" on public.product_variants
for select to anon, authenticated using (is_active = true);

drop policy if exists "Admin can manage product variants" on public.product_variants;
create policy "Admin can manage product variants" on public.product_variants
for all to authenticated using (true) with check (true);

drop policy if exists "Public can view active product sizes" on public.product_sizes;
create policy "Public can view active product sizes" on public.product_sizes
for select to anon, authenticated using (is_active = true);

drop policy if exists "Admin can manage product sizes" on public.product_sizes;
create policy "Admin can manage product sizes" on public.product_sizes
for all to authenticated using (true) with check (true);

-- Replace stock trigger so variant stock is the source of truth when a variant is selected.
create or replace function public.decrement_product_stock()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.variant_id is not null then
    update public.product_variants
    set stock = stock - new.quantity
    where id = new.variant_id
      and product_id = new.product_id
      and is_active = true
      and stock >= new.quantity;
    if not found then
      raise exception 'Stok varian produk tidak mencukupi.';
    end if;

    update public.products
    set stock = stock - new.quantity
    where id = new.product_id
      and stock >= new.quantity;
    if not found then
      raise exception 'Stok produk tidak mencukupi.';
    end if;
  else
    update public.products
    set stock = stock - new.quantity
    where id = new.product_id
      and stock >= new.quantity;
    if not found then
      raise exception 'Stok produk tidak mencukupi.';
    end if;
  end if;
  return new;
end;
$$;

-- Replace cancellation sync to restore/re-reserve variant stock as well.
create or replace function public.sync_stock_on_order_status()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  item record;
begin
  if old.status is distinct from new.status and new.status = 'cancelled' then
    for item in
      select product_id, variant_id, quantity from public.order_items where order_id = new.id
    loop
      if item.variant_id is not null then
        update public.product_variants set stock = stock + item.quantity where id = item.variant_id;
      end if;
      update public.products set stock = stock + item.quantity where id = item.product_id;
    end loop;
  elsif old.status = 'cancelled' and new.status <> 'cancelled' then
    for item in
      select product_id, variant_id, quantity from public.order_items where order_id = new.id
    loop
      if item.variant_id is not null then
        update public.product_variants
        set stock = stock - item.quantity
        where id = item.variant_id and stock >= item.quantity;
        if not found then raise exception 'Stok varian produk tidak mencukupi.'; end if;
      end if;
      update public.products set stock = stock - item.quantity where id = item.product_id and stock >= item.quantity;
      if not found then raise exception 'Stok produk tidak mencukupi.'; end if;
    end loop;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_decrement_product_stock on public.order_items;
create trigger trg_decrement_product_stock before insert on public.order_items for each row execute function public.decrement_product_stock();

drop trigger if exists trg_sync_stock_order_status on public.orders;
create trigger trg_sync_stock_order_status after update of status on public.orders for each row execute function public.sync_stock_on_order_status();

-- Shipping-aware order RPC with optional variant_id and size_name in each item.
drop function if exists public.place_order(text,text,text,text,jsonb,text,text,numeric);
create or replace function public.place_order(
  p_customer_name text,
  p_customer_phone text,
  p_customer_address text,
  p_payment_token text,
  p_items jsonb,
  p_shipping_courier text default 'manual',
  p_shipping_service text default 'Ongkir',
  p_shipping_cost numeric default 15000
)
returns public.orders
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_order public.orders;
  v_item_count integer;
  v_product_total numeric;
  v_shipping_cost numeric;
  v_total numeric;
  v_total_weight integer;
  v_shipping_weight integer;
  v_shipping_confirmed boolean;
begin
  if coalesce(trim(p_customer_name),'')='' or coalesce(trim(p_customer_phone),'')='' or coalesce(trim(p_customer_address),'')='' then raise exception 'Data pelanggan belum lengkap.'; end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'Keranjang kosong.'; end if;
  if p_shipping_cost is null or p_shipping_cost < 0 then raise exception 'Biaya pengiriman tidak valid.'; end if;

  with requested as (
    select x.product_id, x.variant_id, x.size_name, x.quantity
    from jsonb_to_recordset(p_items) as x(product_id uuid, variant_id uuid, size_name text, quantity integer)
  )
  select count(*),
         coalesce(sum(coalesce(v.price, p.price) * r.quantity),0),
         coalesce(sum(coalesce(v.weight_grams, p.weight_grams) * r.quantity),0)
  into v_item_count, v_product_total, v_total_weight
  from requested r
  join public.products p on p.id=r.product_id and p.is_active=true
  left join public.product_variants v on v.id=r.variant_id and v.product_id=r.product_id and v.is_active=true
  where r.quantity > 0
    and (r.variant_id is null or v.id is not null)
    and (r.variant_id is null or v.stock >= r.quantity)
    and p.stock >= r.quantity;

  if v_item_count < jsonb_array_length(p_items) then raise exception 'Ada produk/varian yang tidak tersedia atau jumlah tidak valid.'; end if;

  v_shipping_weight := greatest(1000, ceil(v_total_weight/1000.0)*1000)::integer;
  v_shipping_cost := p_shipping_cost;
  v_total := v_product_total + v_shipping_cost;
  v_shipping_confirmed := lower(trim(coalesce(p_shipping_courier,''))) not in ('grabexpress','maxim');

  insert into public.orders(customer_name,customer_phone,customer_address,total_amount,status,payment_status,payment_token,shipping_courier,shipping_service,shipping_cost,shipping_weight_grams,shipping_confirmed)
  values(trim(p_customer_name),trim(p_customer_phone),trim(p_customer_address),v_total,'pending','unpaid',p_payment_token,coalesce(nullif(trim(p_shipping_courier),''),'manual'),coalesce(nullif(trim(p_shipping_service),''),'Ongkir'),v_shipping_cost,v_shipping_weight,v_shipping_confirmed)
  returning * into v_order;

  insert into public.order_items(order_id,product_id,variant_id,variant_name,size_name,product_name,price,quantity,subtotal)
  select v_order.id,p.id,r.variant_id,coalesce(v.name,''),nullif(trim(r.size_name),''),p.name,coalesce(v.price,p.price),r.quantity,coalesce(v.price,p.price)*r.quantity
  from jsonb_to_recordset(p_items) as r(product_id uuid, variant_id uuid, size_name text, quantity integer)
  join public.products p on p.id=r.product_id and p.is_active=true
  left join public.product_variants v on v.id=r.variant_id and v.product_id=r.product_id and v.is_active=true;

  return v_order;
end;
$function$;

revoke all on function public.place_order(text,text,text,text,jsonb,text,text,numeric) from public;
grant execute on function public.place_order(text,text,text,text,jsonb,text,text,numeric) to anon, authenticated;
