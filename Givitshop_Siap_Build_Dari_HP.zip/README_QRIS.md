# Givitshop QRIS Manual

1. Jalankan `qris_payment_setup.sql` sekali di Supabase SQL Editor.
2. Build APK dari folder `android` menggunakan workflow GitHub Actions yang sudah ada.
3. Customer checkout akan melihat QRIS GIVIT SHOP dan total pembayaran.
4. Setelah menekan `Saya sudah bayar`, status pembayaran menjadi `awaiting_verification`.
5. Admin memverifikasi pembayaran secara manual sebelum memproses pesanan.

QRIS yang digunakan adalah QRIS GIVIT SHOP dengan NMID ID1025372324331.
