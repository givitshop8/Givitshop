# Givitshop — Siap Build APK dari HP

Project ini sudah disiapkan agar APK demo bisa dibuat tanpa laptop menggunakan GitHub Actions.

## Cara paling praktis dari HP

1. Buka GitHub di browser/HP dan login.
2. Buat repository baru, misalnya `givitshop-app`.
3. Upload **isi folder ZIP ini** ke repository (bukan folder ZIP-nya).
4. Pastikan file `.github/workflows/build-apk.yml` ikut ter-upload.
5. Buka tab **Actions** → pilih **Build Givitshop APK** → **Run workflow**.
6. Tunggu sampai status berubah menjadi hijau **Success**.
7. Buka hasil workflow tersebut, cari bagian **Artifacts**, lalu download **Givitshop-APK**.
8. Extract ZIP hasil download dan buka `app-debug.apk` untuk memasangnya di HP.

## Catatan

- Ini adalah APK demo/prototype, bukan versi toko online produksi.
- Produk, login, database, pembayaran, stok, ongkir, notifikasi, dan backend belum nyata.
- APK debug cocok untuk mencoba aplikasi di HP.
- Untuk Play Store nanti perlu AAB release yang ditandatangani (keystore), privacy policy, listing, screenshot, dan konfigurasi Play Console.

Workflow memakai Gradle 8.10.2 dan Java 17.
