-- Givitshop: aktifkan kembali RLS untuk orders/order_items
create or replace function public.place_order(
  p_customer_name text, p_customer_phone text, p_customer_address text,
  p_payment_token text, p_items jsonb
)
returns public.orders
language plpgsql security definer
set search_path = public
as $$
declare
  v_order public.orders; v_item_count integer; v_total numeric;
begin
  if coalesce(trim(p_customer_name),'')='' or coalesce(trim(p_customer_phone),'')='' or coalesce(trim(p_customer_address),'')='' then
    raise exception 'Data pelanggan belum lengkap.';
  end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then
    raise exception 'Keranjang kosong.';
  end if;

  with requested as (
    select x.product_id,x.quantity from jsonb_to_recordset(p_items) as x(product_id uuid,quantity integer)
  )
  select count(*),coalesce(sum(p.price*r.quantity),0) into v_item_count,v_total
  from requested r join public.products p on p.id=r.product_id
  where p.is_active=true and r.quantity>0;

  if v_item_count<>jsonb_array_length(p_items) then
    raise exception 'Ada produk yang tidak tersedia atau jumlah tidak valid.';
  end if;

  v_total:=v_total+15000;
  insert into public.orders(customer_name,customer_phone,customer_address,total_amount,status,payment_status,payment_token)
  values(trim(p_customer_name),trim(p_customer_phone),trim(p_customer_address),v_total,'pending','unpaid',p_payment_token)
  returning * into v_order;

  insert into public.order_items(order_id,product_id,product_name,price,quantity,subtotal)
  select v_order.id,p.id,p.name,p.price,r.quantity,p.price*r.quantity
  from jsonb_to_recordset(p_items) as r(product_id uuid,quantity integer)
  join public.products p on p.id=r.product_id
  where p.is_active=true;

  return v_order;
end;
$$;

revoke all on function public.place_order(text,text,text,text,jsonb) from public;
grant execute on function public.place_order(text,text,text,text,jsonb) to anon,authenticated;

alter table public.orders enable row level security;
alter table public.order_items enable row level security;

drop policy if exists "Orders can be created" on public.orders;
drop policy if exists "Order items can be created" on public.order_items;

drop policy if exists "Authenticated can view orders" on public.orders;
create policy "Authenticated can view orders" on public.orders for select to authenticated using(true);

drop policy if exists "Authenticated can update orders" on public.orders;
create policy "Authenticated can update orders" on public.orders for update to authenticated using(true) with check(true);

drop policy if exists "Authenticated can view order items" on public.order_items;
create policy "Authenticated can view order items" on public.order_items for select to authenticated using(true);
