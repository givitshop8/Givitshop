Jalankan SECURITY_RLS.sql sekali di Supabase SQL Editor. Setelah Success, checkout memakai RPC place_order dan RLS orders/order_items aktif kembali.
