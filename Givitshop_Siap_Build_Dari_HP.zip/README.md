# Givitshop App — Siap Build dari HP

Givitshop adalah prototype aplikasi toko dengan katalog, pencarian, kategori, detail produk, keranjang, checkout, status pesanan, akun, dan preview admin.

**Cara build dari HP:** baca `README_HP.md`, lalu upload project ini ke GitHub dan jalankan GitHub Actions. APK akan muncul sebagai artifact `Givitshop-APK`.

Untuk aplikasi produksi dan Play Store, backend, pembayaran, stok, ongkir, login, privacy policy, signing, dan AAB release masih perlu disiapkan.

\n## Supabase\nAPK ini sudah disiapkan untuk membaca produk aktif dari Supabase dan menyimpan pesanan ke tabel `orders` dan `order_items`. Sebelum build, isi `SUPABASE_ANON_KEY` di `android/app/src/main/assets/index.html` dengan Publishable/anon key Supabase. Jangan gunakan `service_role`.\n