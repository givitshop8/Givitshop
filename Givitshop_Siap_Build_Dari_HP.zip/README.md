# Givitshop App — Siap Build dari HP

Givitshop adalah prototype aplikasi toko dengan katalog, pencarian, kategori, detail produk, keranjang, checkout, status pesanan, akun, dan preview admin.

**Cara build dari HP:** baca `README_HP.md`, lalu upload project ini ke GitHub dan jalankan GitHub Actions. APK akan muncul sebagai artifact `Givitshop-APK`.

Untuk aplikasi produksi dan Play Store, backend, pembayaran, stok, ongkir, login, privacy policy, signing, dan AAB release masih perlu disiapkan.
