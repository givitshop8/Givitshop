-- Givitshop Multi Varian: kombinasi varian+ukuran, harga/berat/stok opsi,
-- stok otomatis, dan data order menyimpan kombinasi yang dipilih.

create or replace function public.decrement_product_stock()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_option_id uuid;
begin
  if NEW.variant_id is not null and nullif(trim(coalesce(NEW.size_name,'')),'') is not null then
    select o.id into v_option_id
    from public.product_variant_options o
    join public.product_sizes s on s.id=o.size_id
    where o.product_id=NEW.product_id
      and o.variant_id=NEW.variant_id
      and lower(trim(s.name))=lower(trim(NEW.size_name))
      and o.is_active=true
    limit 1;

    if v_option_id is null then
      raise exception 'Kombinasi varian dan ukuran tidak ditemukan.';
    end if;

    update public.product_variant_options
    set stock = stock - NEW.quantity
    where id=v_option_id and stock >= NEW.quantity;
    if not found then raise exception 'Stok kombinasi varian tidak mencukupi.'; end if;
  elsif NEW.variant_id is not null then
    update public.product_variants
    set stock = stock - NEW.quantity
    where id=NEW.variant_id and stock >= NEW.quantity;
    if not found then raise exception 'Stok varian produk tidak mencukupi.'; end if;
  end if;

  update public.products
  set stock = stock - NEW.quantity
  where id=NEW.product_id and stock >= NEW.quantity;
  if not found then raise exception 'Stok produk tidak mencukupi.'; end if;

  return NEW;
end;
$$;

drop trigger if exists trg_decrement_product_stock on public.order_items;
create trigger trg_decrement_product_stock
before insert on public.order_items
for each row execute function public.decrement_product_stock();

create or replace function public.sync_stock_on_order_status()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  item record;
  v_option_id uuid;
begin
  if old.status is distinct from new.status and new.status='cancelled' then
    for item in
      select product_id, variant_id, size_name, quantity
      from public.order_items where order_id=new.id
    loop
      if item.variant_id is not null and nullif(trim(coalesce(item.size_name,'')),'') is not null then
        select o.id into v_option_id
        from public.product_variant_options o
        join public.product_sizes s on s.id=o.size_id
        where o.product_id=item.product_id
          and o.variant_id=item.variant_id
          and lower(trim(s.name))=lower(trim(item.size_name))
        limit 1;
        if v_option_id is not null then
          update public.product_variant_options set stock=stock+item.quantity where id=v_option_id;
        end if;
      elsif item.variant_id is not null then
        update public.product_variants set stock=stock+item.quantity where id=item.variant_id;
      end if;
      update public.products set stock=stock+item.quantity where id=item.product_id;
    end loop;
  elsif old.status='cancelled' and new.status<>'cancelled' then
    for item in
      select product_id, variant_id, size_name, quantity
      from public.order_items where order_id=new.id
    loop
      if item.variant_id is not null and nullif(trim(coalesce(item.size_name,'')),'') is not null then
        select o.id into v_option_id
        from public.product_variant_options o
        join public.product_sizes s on s.id=o.size_id
        where o.product_id=item.product_id
          and o.variant_id=item.variant_id
          and lower(trim(s.name))=lower(trim(item.size_name))
        limit 1;
        if v_option_id is null then raise exception 'Kombinasi varian dan ukuran tidak ditemukan.'; end if;
        update public.product_variant_options set stock=stock-item.quantity where id=v_option_id and stock>=item.quantity;
        if not found then raise exception 'Stok kombinasi varian tidak mencukupi.'; end if;
      elsif item.variant_id is not null then
        update public.product_variants set stock=stock-item.quantity where id=item.variant_id and stock>=item.quantity;
        if not found then raise exception 'Stok varian produk tidak mencukupi.'; end if;
      end if;
      update public.products set stock=stock-item.quantity where id=item.product_id and stock>=item.quantity;
      if not found then raise exception 'Stok produk tidak mencukupi.'; end if;
    end loop;
  end if;
  return new;
end;
$$;

drop trigger if exists trg_sync_stock_order_status on public.orders;
create trigger trg_sync_stock_order_status
after update of status on public.orders
for each row execute function public.sync_stock_on_order_status();

create or replace function public.place_order(
  p_customer_name text,
  p_customer_phone text,
  p_customer_address text,
  p_payment_token text,
  p_items jsonb,
  p_shipping_courier text default 'manual',
  p_shipping_service text default 'Ongkir',
  p_shipping_cost numeric default 15000
)
returns public.orders
language plpgsql
security definer
set search_path=public
as $$
declare
  v_order public.orders;
  v_item_count integer;
  v_product_total numeric;
  v_shipping_cost numeric;
  v_total numeric;
  v_total_weight integer;
  v_shipping_weight integer;
  v_shipping_confirmed boolean;
begin
  if coalesce(trim(p_customer_name),'')='' or coalesce(trim(p_customer_phone),'')='' or coalesce(trim(p_customer_address),'')='' then raise exception 'Data pelanggan belum lengkap.'; end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then raise exception 'Keranjang kosong.'; end if;
  if p_shipping_cost is null or p_shipping_cost<0 then raise exception 'Biaya pengiriman tidak valid.'; end if;

  with requested as (
    select x.product_id,x.variant_id,x.size_name,x.quantity
    from jsonb_to_recordset(p_items) as x(product_id uuid,variant_id uuid,size_name text,quantity integer)
  )
  select count(*),
    coalesce(sum(coalesce(o.price,v.price,p.price)*r.quantity),0),
    coalesce(sum(coalesce(o.weight_grams,v.weight_grams,p.weight_grams)*r.quantity),0)
  into v_item_count,v_product_total,v_total_weight
  from requested r
  join public.products p on p.id=r.product_id and p.is_active=true
  left join public.product_variants v on v.id=r.variant_id and v.product_id=r.product_id and v.is_active=true
  left join public.product_sizes s on s.product_id=r.product_id and lower(trim(s.name))=lower(trim(r.size_name)) and s.is_active=true
  left join public.product_variant_options o on o.product_id=r.product_id and o.variant_id=r.variant_id and o.size_id=s.id and o.is_active=true
  where r.quantity>0
    and (r.variant_id is null or v.id is not null)
    and (r.variant_id is null or r.size_name is null or o.id is not null)
    and (r.variant_id is null or r.size_name is null or o.stock>=r.quantity)
    and (r.variant_id is not null or p.stock>=r.quantity);

  if v_item_count < jsonb_array_length(p_items) then raise exception 'Ada produk/varian/ukuran yang tidak tersedia atau stok tidak mencukupi.'; end if;

  v_shipping_weight:=greatest(1000,ceil(v_total_weight/1000.0)*1000)::integer;
  v_shipping_cost:=p_shipping_cost;
  v_total:=v_product_total+v_shipping_cost;
  v_shipping_confirmed:=lower(trim(coalesce(p_shipping_courier,''))) not in ('grabexpress','maxim');

  insert into public.orders(customer_name,customer_phone,customer_address,total_amount,status,payment_status,payment_token,shipping_courier,shipping_service,shipping_cost,shipping_weight_grams,shipping_confirmed)
  values(trim(p_customer_name),trim(p_customer_phone),trim(p_customer_address),v_total,'pending','unpaid',p_payment_token,coalesce(nullif(trim(p_shipping_courier),''),'manual'),coalesce(nullif(trim(p_shipping_service),''),'Ongkir'),v_shipping_cost,v_shipping_weight,v_shipping_confirmed)
  returning * into v_order;

  insert into public.order_items(order_id,product_id,variant_id,variant_name,size_name,product_name,price,quantity,subtotal)
  select v_order.id,p.id,r.variant_id,coalesce(v.name,''),nullif(trim(r.size_name),''),p.name,coalesce(o.price,v.price,p.price),r.quantity,coalesce(o.price,v.price,p.price)*r.quantity
  from jsonb_to_recordset(p_items) as r(product_id uuid,variant_id uuid,size_name text,quantity integer)
  join public.products p on p.id=r.product_id and p.is_active=true
  left join public.product_variants v on v.id=r.variant_id and v.product_id=r.product_id and v.is_active=true
  left join public.product_sizes s on s.product_id=r.product_id and lower(trim(s.name))=lower(trim(r.size_name)) and s.is_active=true
  left join public.product_variant_options o on o.product_id=r.product_id and o.variant_id=r.variant_id and o.size_id=s.id and o.is_active=true;

  return v_order;
end;
$$;

revoke all on function public.place_order(text,text,text,text,jsonb,text,text,numeric) from public;
grant execute on function public.place_order(text,text,text,text,jsonb,text,text,numeric) to anon,authenticated;
