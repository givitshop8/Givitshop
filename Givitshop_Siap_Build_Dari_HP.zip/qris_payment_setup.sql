-- Givitshop QRIS manual payment setup
-- Run this once in Supabase SQL Editor.
alter table public.orders
  add column if not exists payment_token text;

create unique index if not exists orders_payment_token_uidx
  on public.orders(payment_token)
  where payment_token is not null;

create or replace function public.confirm_order_payment(
  p_order_id bigint,
  p_payment_token text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.orders
  set payment_status = 'awaiting_verification'
  where id = p_order_id
    and payment_token = p_payment_token
    and payment_status = 'unpaid';

  if not found then
    raise exception 'Pesanan tidak ditemukan atau token pembayaran tidak valid.';
  end if;
end;
$$;

revoke all on function public.confirm_order_payment(bigint, text) from public;
grant execute on function public.confirm_order_payment(bigint, text) to anon, authenticated;
