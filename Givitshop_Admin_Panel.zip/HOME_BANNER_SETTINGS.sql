-- Givitshop: pengaturan foto banner halaman utama
create table if not exists public.homepage_settings (
  id text primary key check (id = 'main'),
  hero_image_url text,
  updated_at timestamptz not null default now()
);

alter table public.homepage_settings enable row level security;
grant select on public.homepage_settings to anon, authenticated;
grant insert, update, delete on public.homepage_settings to authenticated;

drop policy if exists "homepage_settings_public_read" on public.homepage_settings;
create policy "homepage_settings_public_read"
  on public.homepage_settings for select to anon, authenticated using (true);

drop policy if exists "homepage_settings_admin_insert" on public.homepage_settings;
create policy "homepage_settings_admin_insert"
  on public.homepage_settings for insert to authenticated
  with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "homepage_settings_admin_update" on public.homepage_settings;
create policy "homepage_settings_admin_update"
  on public.homepage_settings for update to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "homepage_settings_admin_delete" on public.homepage_settings;
create policy "homepage_settings_admin_delete"
  on public.homepage_settings for delete to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Upload file banner ke bucket product-images, folder homepage/.
drop policy if exists "givit_home_banner_insert" on storage.objects;
create policy "givit_home_banner_insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'product-images' and name like 'homepage/%' and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
drop policy if exists "givit_home_banner_update" on storage.objects;
create policy "givit_home_banner_update" on storage.objects for update to authenticated
  using (bucket_id = 'product-images' and name like 'homepage/%' and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  with check (bucket_id = 'product-images' and name like 'homepage/%' and (auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
