-- Givitshop admin-created vouchers
-- Run once in Supabase SQL Editor.
create table if not exists public.vouchers (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  code text not null,
  description text not null default '',
  discount_type text not null check (discount_type in ('percent','fixed')),
  discount_value numeric(12,2) not null check (discount_value > 0),
  min_purchase numeric(12,2) not null default 0 check (min_purchase >= 0),
  start_at timestamptz,
  end_at timestamptz,
  usage_limit integer check (usage_limit is null or usage_limit > 0),
  used_count integer not null default 0 check (used_count >= 0),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  constraint vouchers_code_unique unique (code),
  constraint vouchers_percent_max check (discount_type <> 'percent' or discount_value <= 100),
  constraint vouchers_dates_valid check (start_at is null or end_at is null or end_at > start_at)
);

alter table public.vouchers enable row level security;
grant select on public.vouchers to anon, authenticated;
grant insert, update, delete on public.vouchers to authenticated;

drop policy if exists "Public can view active vouchers" on public.vouchers;
create policy "Public can view active vouchers"
  on public.vouchers for select to anon, authenticated
  using (
    is_active = true
    and (start_at is null or start_at <= now())
    and (end_at is null or end_at >= now())
    and (usage_limit is null or used_count < usage_limit)
  );

drop policy if exists "Admin can view all vouchers" on public.vouchers;
create policy "Admin can view all vouchers"
  on public.vouchers for select to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Admin can create vouchers" on public.vouchers;
create policy "Admin can create vouchers"
  on public.vouchers for insert to authenticated
  with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Admin can update vouchers" on public.vouchers;
create policy "Admin can update vouchers"
  on public.vouchers for update to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Admin can delete vouchers" on public.vouchers;
create policy "Admin can delete vouchers"
  on public.vouchers for delete to authenticated
  using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
