-- Givitshop Admin: jalankan di Supabase SQL Editor
-- Tujuan: hanya user yang sudah login yang boleh membaca/mengelola data admin.
-- Checkout pelanggan tetap boleh membuat order sebagai anon.

-- PRODUCTS: publik hanya boleh membaca produk aktif; admin/login boleh mengelola.
drop policy if exists "Products are publicly readable" on public.products;
drop policy if exists "Public can view active products" on public.products;
create policy "Public can view active products"
on public.products for select
to anon, authenticated
using (is_active = true);

create policy "Authenticated can manage products"
on public.products for all
to authenticated
using (true)
with check (true);

-- ORDERS: pelanggan boleh INSERT, tetapi daftar pesanan hanya untuk admin/login.
drop policy if exists "Orders can be viewed" on public.orders;
drop policy if exists "Authenticated can view orders" on public.orders;
create policy "Authenticated can view orders"
on public.orders for select
to authenticated
using (true);

create policy "Authenticated can update orders"
on public.orders for update
to authenticated
using (true)
with check (true);

-- ORDER ITEMS
drop policy if exists "Order items can be viewed" on public.order_items;
drop policy if exists "Authenticated can view order items" on public.order_items;
create policy "Authenticated can view order items"
on public.order_items for select
to authenticated
using (true);

-- STORAGE: admin/login boleh upload, update, delete foto produk.
create policy "Authenticated upload product images"
on storage.objects for insert
to authenticated
with check (bucket_id = 'product-images');

create policy "Authenticated update product images"
on storage.objects for update
to authenticated
using (bucket_id = 'product-images')
with check (bucket_id = 'product-images');

create policy "Authenticated delete product images"
on storage.objects for delete
to authenticated
using (bucket_id = 'product-images');

-- Setelah menjalankan SQL ini:
-- 1. Supabase > Authentication > Users > Add user
-- 2. Buat akun admin, misalnya admin@givitshop.com + password kuat.
-- 3. Jangan gunakan service_role key di browser.

-- Batas berat produk Givitshop: 100–1000 gram
alter table public.products drop constraint if exists products_weight_grams_check;
alter table public.products add constraint products_weight_grams_check check (weight_grams between 100 and 1000);
alter table public.products alter column weight_grams set default 100;
