Givitshop Admin V53
Ganti file admin/index.html pada repository dengan file ini.
Jika penghapusan ditolak, periksa kebijakan RLS DELETE di Supabase untuk orders, order_items, chat_messages, dan chat_conversations.
