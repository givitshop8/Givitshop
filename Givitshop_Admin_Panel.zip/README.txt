Givitshop Admin V52
Ganti file admin/index.html di repository dengan file pada paket ini.
Perubahan: refresh token Supabase, pemulihan sesi admin, dan penghapusan pesanan beserta item/chat terkait.
Uji di Supabase sebelum menghapus data penting.
