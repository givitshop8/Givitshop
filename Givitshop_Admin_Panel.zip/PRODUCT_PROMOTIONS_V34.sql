-- Givitshop product-specific automatic promotions V34
-- Run this entire file in Supabase SQL Editor after the existing app schema is installed.

create table if not exists public.product_promotions (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null unique references public.products(id) on delete cascade,
  title text not null default 'Promo Givitshop',
  discount_type text not null check (discount_type in ('percent','fixed')),
  discount_value numeric(12,2) not null check (discount_value > 0),
  start_at timestamptz,
  end_at timestamptz,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint product_promotions_percent_max check (discount_type <> 'percent' or discount_value <= 100),
  constraint product_promotions_dates_valid check (start_at is null or end_at is null or end_at > start_at)
);

alter table public.product_promotions enable row level security;
grant select on public.product_promotions to anon, authenticated;
grant insert, update, delete on public.product_promotions to authenticated;

drop policy if exists "Public can view current product promotions" on public.product_promotions;
create policy "Public can view current product promotions"
on public.product_promotions for select to anon, authenticated
using (
  is_active = true
  and (start_at is null or start_at <= now())
  and (end_at is null or end_at >= now())
);

drop policy if exists "Admin can view all product promotions" on public.product_promotions;
create policy "Admin can view all product promotions"
on public.product_promotions for select to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Admin can create product promotions" on public.product_promotions;
create policy "Admin can create product promotions"
on public.product_promotions for insert to authenticated
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Admin can update product promotions" on public.product_promotions;
create policy "Admin can update product promotions"
on public.product_promotions for update to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
with check ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

drop policy if exists "Admin can delete product promotions" on public.product_promotions;
create policy "Admin can delete product promotions"
on public.product_promotions for delete to authenticated
using ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Rebuild the existing shipping-aware order RPC with server-side promo calculation.
-- Product/variant availability, stock decrement triggers, shipping fields and payment flow remain intact.
create or replace function public.place_order(
  p_customer_name text,
  p_customer_phone text,
  p_customer_address text,
  p_payment_token text,
  p_items jsonb,
  p_shipping_courier text default 'manual',
  p_shipping_service text default 'Ongkir',
  p_shipping_cost numeric default 15000
)
returns public.orders
language plpgsql
security definer
set search_path = public
as $function$
declare
  v_order public.orders;
  v_item_count integer;
  v_product_total numeric;
  v_shipping_cost numeric;
  v_total numeric;
  v_total_weight integer;
  v_shipping_weight integer;
  v_shipping_confirmed boolean;
begin
  if coalesce(trim(p_customer_name),'')='' or coalesce(trim(p_customer_phone),'')='' or coalesce(trim(p_customer_address),'')='' then
    raise exception 'Data pelanggan belum lengkap.';
  end if;
  if p_items is null or jsonb_typeof(p_items)<>'array' or jsonb_array_length(p_items)=0 then
    raise exception 'Keranjang kosong.';
  end if;
  if p_shipping_cost is null or p_shipping_cost < 0 then
    raise exception 'Biaya pengiriman tidak valid.';
  end if;

  with requested as (
    select x.product_id, x.variant_id, x.size_name, x.quantity
    from jsonb_to_recordset(p_items) as x(product_id uuid, variant_id uuid, size_name text, quantity integer)
  ), priced as (
    select r.*, p.stock as product_stock, coalesce(v.stock, p.stock) as variant_stock,
           coalesce(v.price,p.price) as base_price,
           coalesce(v.weight_grams,p.weight_grams,1000) as unit_weight,
           promo.discount_type, promo.discount_value
    from requested r
    join public.products p on p.id=r.product_id and p.is_active=true
    left join public.product_variants v on v.id=r.variant_id and v.product_id=r.product_id and v.is_active=true
    left join lateral (
      select pp.discount_type, pp.discount_value
      from public.product_promotions pp
      where pp.product_id=p.id and pp.is_active=true
        and (pp.start_at is null or pp.start_at<=now())
        and (pp.end_at is null or pp.end_at>=now())
      limit 1
    ) promo on true
    where r.quantity>0 and (r.variant_id is null or v.id is not null)
      and (r.variant_id is null or v.stock>=r.quantity)
      and p.stock>=r.quantity
  )
  select count(*),
         coalesce(sum(greatest(0,round(case
           when discount_type='percent' then base_price*(1-least(discount_value,100)/100)
           when discount_type='fixed' then base_price-discount_value
           else base_price end,0))*quantity),0),
         coalesce(sum(unit_weight*quantity),0)
  into v_item_count,v_product_total,v_total_weight
  from priced;

  if v_item_count < jsonb_array_length(p_items) then
    raise exception 'Ada produk/varian yang tidak tersedia atau jumlah tidak valid.';
  end if;

  v_shipping_weight := greatest(1000, ceil(v_total_weight/1000.0)*1000)::integer;
  v_shipping_cost := p_shipping_cost;
  v_total := v_product_total + v_shipping_cost;
  v_shipping_confirmed := lower(trim(coalesce(p_shipping_courier,''))) not in ('grabexpress','maxim');

  insert into public.orders(customer_name,customer_phone,customer_address,total_amount,status,payment_status,payment_token,shipping_courier,shipping_service,shipping_cost,shipping_weight_grams,shipping_confirmed)
  values(trim(p_customer_name),trim(p_customer_phone),trim(p_customer_address),v_total,'pending','unpaid',p_payment_token,coalesce(nullif(trim(p_shipping_courier),''),'manual'),coalesce(nullif(trim(p_shipping_service),''),'Ongkir'),v_shipping_cost,v_shipping_weight,v_shipping_confirmed)
  returning * into v_order;

  insert into public.order_items(order_id,product_id,variant_id,variant_name,size_name,product_name,price,quantity,subtotal)
  select v_order.id,p.id,r.variant_id,coalesce(v.name,''),nullif(trim(r.size_name),''),p.name,
         greatest(0,round(case
           when promo.discount_type='percent' then coalesce(v.price,p.price)*(1-least(promo.discount_value,100)/100)
           when promo.discount_type='fixed' then coalesce(v.price,p.price)-promo.discount_value
           else coalesce(v.price,p.price) end,0)),
         r.quantity,
         greatest(0,round(case
           when promo.discount_type='percent' then coalesce(v.price,p.price)*(1-least(promo.discount_value,100)/100)
           when promo.discount_type='fixed' then coalesce(v.price,p.price)-promo.discount_value
           else coalesce(v.price,p.price) end,0))*r.quantity
  from jsonb_to_recordset(p_items) as r(product_id uuid, variant_id uuid, size_name text, quantity integer)
  join public.products p on p.id=r.product_id and p.is_active=true
  left join public.product_variants v on v.id=r.variant_id and v.product_id=r.product_id and v.is_active=true
  left join lateral (
    select pp.discount_type,pp.discount_value from public.product_promotions pp
    where pp.product_id=p.id and pp.is_active=true
      and (pp.start_at is null or pp.start_at<=now())
      and (pp.end_at is null or pp.end_at>=now())
    limit 1
  ) promo on true;

  return v_order;
end;
$function$;

revoke all on function public.place_order(text,text,text,text,jsonb,text,text,numeric) from public;
grant execute on function public.place_order(text,text,text,text,jsonb,text,text,numeric) to anon, authenticated;
