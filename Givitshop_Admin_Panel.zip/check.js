
const SUPABASE_URL='https://oaojkkhvscbufpakunrs.supabase.co';
const SUPABASE_KEY='sb_publishable_jeoQMVZMgtnJeUR9tsq8tg_owYrhU-S';
let token=null, products=[], orders=[];
let editingVariants=[], editingSizes=[];
const SEEN_ORDER_KEY='givit_admin_seen_order_ids_v1';
let seenOrderIds=new Set();
function loadSeenOrderIds(){try{seenOrderIds=new Set(JSON.parse(localStorage.getItem(SEEN_ORDER_KEY)||'[]').map(String))}catch(e){seenOrderIds=new Set()}}
function saveSeenOrderIds(){localStorage.setItem(SEEN_ORDER_KEY,JSON.stringify([...seenOrderIds].slice(-500)))}
function markOrderSeen(id){seenOrderIds.add(String(id));saveSeenOrderIds();renderNewOrderAlert()}
function renderNewOrderAlert(){const fresh=orders.filter(o=>!seenOrderIds.has(String(o.id)));const alert=document.getElementById('newOrderAlert'),count=document.getElementById('newOrderCount'),badge=document.getElementById('newOrderBadge');if(!alert)return;count.textContent=`${fresh.length} pesanan baru`;alert.classList.toggle('show',fresh.length>0);badge.textContent=fresh.length;badge.style.display=fresh.length?'inline-flex':'none'}
function showNewOrders(){showTab('orders');const f=document.getElementById('orderFilter');if(f)f.value='all';renderOrders();document.getElementById('ordersTab')?.scrollIntoView({behavior:'smooth',block:'start'})}

const headers=()=>({'apikey':SUPABASE_KEY,'Authorization':'Bearer '+token,'Content-Type':'application/json'});
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
const money=n=>new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(Number(n)||0);
async function api(path,opt={}){let r=await fetch(SUPABASE_URL+path,{...opt,headers:{...headers(),...(opt.headers||{})}});let t=await r.text();let d=t?JSON.parse(t):null;if(!r.ok)throw Error(d?.message||d?.hint||t||r.status);return d}
async function login(){
 const msg=document.getElementById('loginMsg');msg.textContent='Memproses...';
 try{const r=await fetch(SUPABASE_URL+'/auth/v1/token?grant_type=password',{method:'POST',headers:{'apikey':SUPABASE_KEY,'Content-Type':'application/json'},body:JSON.stringify({email:email.value,password:password.value})});
 const d=await r.json();if(!r.ok)throw Error(d.error_description||d.msg||'Login gagal');token=d.access_token;sessionStorage.setItem('givit_admin_token',token);document.getElementById('login').classList.add('hidden');document.getElementById('app').classList.remove('hidden');await refresh()}catch(e){msg.textContent=e.message}}
function logout(){sessionStorage.removeItem('givit_admin_token');location.reload()}
async function refresh(){await Promise.all([loadProducts(),loadOrders()]);renderStats();renderNewOrderAlert()}
async function pollOrders(){try{await loadOrders();renderStats();renderNewOrderAlert()}catch(e){}}
setInterval(()=>{if(token)pollOrders()},30000)
async function loadProducts(){
 const [ps,vs,ss,os,imgs]=await Promise.all([api('/rest/v1/products?select=*&order=created_at.desc'),api('/rest/v1/product_variants?select=*&order=created_at.asc'),api('/rest/v1/product_sizes?select=*&order=created_at.asc'),api('/rest/v1/product_variant_options?select=*&order=created_at.asc'),api('/rest/v1/product_images?select=*&order=sort_order.asc')]);
 products=ps.map(p=>({...p,images:imgs.filter(x=>String(x.product_id)===String(p.id)).sort((a,b)=>Number(a.sort_order||0)-Number(b.sort_order||0)),variants:vs.filter(v=>String(v.product_id)===String(p.id)),sizes:ss.filter(x=>String(x.product_id)===String(p.id)),options:os.filter(o=>String(o.product_id)===String(p.id))}));
 renderProducts();
}
async function loadOrders(){const firstLoad=orders.length===0;orders=await api('/rest/v1/orders?select=*&order=created_at.desc');if(firstLoad && seenOrderIds.size===0 && orders.length){orders.forEach(o=>seenOrderIds.add(String(o.id)));saveSeenOrderIds()}renderOrders();renderNewOrderAlert()}
function renderStats(){
 const now=new Date();
 const todayKey=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Makassar',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
 const todayOrders=orders.filter(o=>{const d=new Date(o.created_at);const key=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Makassar',year:'numeric',month:'2-digit',day:'2-digit'}).format(d);return key===todayKey}).length;
 const unpaid=orders.filter(o=>o.payment_status==='unpaid' && o.status!=='cancelled').length;
 const pendingProcess=orders.filter(o=>o.status==='pending' && o.shipping_confirmed!==false && o.payment_status!=='unpaid').length;
 const lowStock=products.filter(p=>p.is_active && Number(p.stock)>0 && Number(p.stock)<=10).length;
 statProducts.textContent=products.filter(x=>x.is_active).length;
 statToday.textContent=todayOrders;
 statUnpaid.textContent=unpaid;
 statProcessing.textContent=pendingProcess;
 statLowStock.textContent=lowStock;
}
function renderProducts(){const q=(document.getElementById('productSearch')?.value||'').trim().toLocaleLowerCase('id-ID');const shown=products.filter(p=>[p.name,p.brand,p.category].some(v=>String(v||'').toLocaleLowerCase('id-ID').includes(q)));productRows.innerHTML=shown.map(p=>{const stock=Number(p.stock)||0;const cls=stock===0?'stock-out':(stock<=10?'stock-low':'stock-ok');const label=stock===0?'🔴 Habis':(stock<=10?'🟡 Menipis':'🟢 Aman');return `<tr><td>${p.image_url?`<img class="thumb" src="${esc(p.image_url)}">`:''}</td><td><b>${esc(p.name)}</b><br><span class="muted">${esc(p.brand||'')}${p.variants?.length?` · ${p.variants.length} varian`:''}${p.sizes?.length?` · ${p.sizes.length} ukuran`:''}</span></td><td>${esc(p.category)}</td><td>${money(p.price)}</td><td><span class="badge ${cls}">${label}</span><br><span class="muted">${stock} pcs</span></td><td>${Number(p.weight_grams||1000).toLocaleString('id-ID')} g</td><td>${p.is_active?'Aktif':'Nonaktif'}</td><td><div class="row-actions"><button class="btn secondary" onclick="editProduct('${p.id}')">Edit</button><button class="btn danger" onclick="deleteProduct('${p.id}')">Hapus</button></div></td></tr>`}).join('')}
function editProduct(id){
 let p=products.find(x=>x.id===id);if(!p)return;
 pid.value=p.id;pname.value=p.name||'';pbrand.value=p.brand||'';pcat.value=p.category||'';pprice.value=p.price||0;pstock.value=p.stock||0;pweight.value=p.weight_grams||100;pactive.value=String(!!p.is_active);pdesc.value=p.description||'';
 editingVariants=(p.variants||[]).map(v=>{const options={};(p.options||[]).filter(o=>String(o.variant_id)===String(v.id)).forEach(o=>options[String(o.size_id)]={...o});return {...v,options}});
 editingSizes=(p.sizes||[]).map(x=>({...x}));document.getElementById('productImagePreview').innerHTML=(p.images||[]).length?`Foto tersimpan: ${(p.images||[]).length} foto`:'Belum ada foto tambahan.';renderVariantEditor();renderSizeEditor();scrollTo(0,0)
}
function resetProduct(){['pid','pname','pbrand','pcat','pprice','pstock','pweight','pdesc'].forEach(id=>document.getElementById(id).value='');pactive.value='true';pimage.value='';document.getElementById('productImagePreview').textContent='Pilih beberapa foto untuk membuat slide foto produk.';editingVariants=[];editingSizes=[];renderVariantEditor();renderSizeEditor()}
function addVariantRow(){editingVariants.push({id:null,name:'',image_url:'',is_active:true,options:{}});renderVariantEditor()}
function removeVariantRow(i){editingVariants.splice(i,1);renderVariantEditor()}
function addSizeRow(){editingSizes.push({id:null,name:'',is_active:true});renderSizeEditor();renderVariantEditor()}
function removeSizeRow(i){editingSizes.splice(i,1);renderSizeEditor();renderVariantEditor()}
function optionFor(v,sizeId){return (v.options||{})[String(sizeId)]||{price:'',stock:0,weight_grams:100}}
function renderVariantEditor(){
 const el=document.getElementById('variantEditor');if(!el)return;
 const sizes=editingSizes.filter(x=>String(x.name||'').trim());
 if(!editingVariants.length){el.innerHTML='<div class="muted">Belum ada varian.</div>';return}
 let head=`<div style="overflow:auto"><table style="width:100%;min-width:${Math.max(760,420+sizes.length*270)}px;border-collapse:collapse"><thead><tr><th style="padding:8px;border-bottom:1px solid var(--line)">No</th><th style="padding:8px;border-bottom:1px solid var(--line)">Nama Varian</th><th style="padding:8px;border-bottom:1px solid var(--line)">Gambar</th>`;
 sizes.forEach(z=>{head+=`<th colspan="3" style="padding:8px;border-bottom:1px solid var(--line);text-align:center">${esc(z.name)}<div style="font-size:10px;color:#777;font-weight:400">Harga · Stok · Berat</div></th>`});
 head+='<th style="padding:8px;border-bottom:1px solid var(--line)">Aksi</th></tr></thead><tbody>';
 let rows=editingVariants.map((v,i)=>{
   let r=`<tr><td style="padding:8px;border-bottom:1px solid var(--line)">${i+1}</td><td style="padding:8px;border-bottom:1px solid var(--line);min-width:150px"><input class="vname" data-i="${i}" value="${esc(v.name||'')}" placeholder="Daily Bright"></td><td style="padding:8px;border-bottom:1px solid var(--line);min-width:150px"><div style="display:flex;align-items:center;gap:7px">${v.image_url?`<img src="${esc(v.image_url)}" style="width:48px;height:48px;object-fit:cover;border-radius:8px;border:1px solid var(--line)">`:''}<input class="vfile" data-i="${i}" type="file" accept="image/*" style="max-width:140px"></div></td>`;
   sizes.forEach(z=>{const o=optionFor(v,z.id);r+=`<td style="padding:8px;border-bottom:1px solid var(--line);min-width:95px"><input class="oprice" data-i="${i}" data-sid="${z.id}" type="number" min="0" value="${o.price??''}" placeholder="Harga"></td><td style="padding:8px;border-bottom:1px solid var(--line);min-width:75px"><input class="ostock" data-i="${i}" data-sid="${z.id}" type="number" min="0" value="${o.stock??0}" placeholder="Stok"></td><td style="padding:8px;border-bottom:1px solid var(--line);min-width:80px"><input class="oweight" data-i="${i}" data-sid="${z.id}" type="number" min="1" max="1000" value="${o.weight_grams||100}" placeholder="g"></td>`});
   r+=`<td style="padding:8px;border-bottom:1px solid var(--line)"><button type="button" class="btn danger mini" onclick="removeVariantRow(${i})">Hapus</button></td></tr>`;return r;
 }).join('');
 el.innerHTML=head+rows+'</tbody></table></div>';
 el.querySelectorAll('input').forEach(inp=>inp.addEventListener('input',()=>{
   const i=Number(inp.dataset.i);if(inp.classList.contains('vname')) editingVariants[i].name=inp.value;
   if(inp.classList.contains('oprice')||inp.classList.contains('ostock')||inp.classList.contains('oweight')){const sid=String(inp.dataset.sid);editingVariants[i].options=editingVariants[i].options||{};editingVariants[i].options[sid]=editingVariants[i].options[sid]||{};if(inp.classList.contains('oprice'))editingVariants[i].options[sid].price=inp.value;if(inp.classList.contains('ostock'))editingVariants[i].options[sid].stock=Number(inp.value||0);if(inp.classList.contains('oweight'))editingVariants[i].options[sid].weight_grams=Number(inp.value||100)}
 }));
 el.querySelectorAll('.vfile').forEach(inp=>inp.addEventListener('change',()=>{const i=Number(inp.dataset.i);editingVariants[i].file=inp.files[0]||null}));
}
function renderSizeEditor(){const el=document.getElementById('sizeEditor');if(!el)return;el.innerHTML=editingSizes.map((v,i)=>`<div class="size-line"><input data-i="${i}" class="sname" value="${esc(v.name||'')}" placeholder="100ml"><button type="button" class="btn danger mini" onclick="removeSizeRow(${i})">Hapus</button></div>`).join('')||'<div class="muted">Belum ada ukuran.</div>';el.querySelectorAll('.sname').forEach(inp=>inp.addEventListener('input',()=>{editingSizes[Number(inp.dataset.i)].name=inp.value;renderVariantEditor()}))}

async function uploadVariantImage(id,file,oldUrl){if(!file)return oldUrl||null;const ext=(file.name.split('.').pop()||'jpg').toLowerCase();const path=`variants/${id}.${ext}`;const r=await fetch(SUPABASE_URL+'/storage/v1/object/product-images/'+path,{method:'POST',headers:{'apikey':SUPABASE_KEY,'Authorization':'Bearer '+token,'Content-Type':file.type,'x-upsert':'true'},body:file});if(!r.ok)throw Error(await r.text());return SUPABASE_URL+'/storage/v1/object/public/product-images/'+path}
async function uploadProductImage(id,file,index){const ext=(file.name.split('.').pop()||'jpg').toLowerCase();const path=`products/${id}-${index}.${ext}`;const r=await fetch(SUPABASE_URL+'/storage/v1/object/product-images/'+path,{method:'POST',headers:{'apikey':SUPABASE_KEY,'Authorization':'Bearer '+token,'Content-Type':file.type,'x-upsert':'true'},body:file});if(!r.ok)throw Error(await r.text());return SUPABASE_URL+'/storage/v1/object/public/product-images/'+path}
async function saveProduct(){
 productMsg.textContent='Menyimpan...';try{
  let id=pid.value||crypto.randomUUID(), image_url=products.find(x=>x.id===id)?.image_url||null;const files=Array.from(pimage.files||[]);
  if(files.length){image_url=await uploadProductImage(id,files[0],0)}
  const weight=Math.round(Number(pweight.value||100));if(weight<1||weight>1000){alert('Berat produk harus 1–1000 gram.');return;}
  const old=products.find(x=>x.id===id);const oldVariants=old?.variants||[];const oldSizes=old?.sizes||[];
  const cleanSizes=editingSizes.filter(v=>String(v.name||'').trim()).map(v=>({id:v.id||crypto.randomUUID(),product_id:id,name:String(v.name).trim(),is_active:true}));
  const sizeIds=new Set(cleanSizes.map(x=>String(x.id)));
  const cleanVariants=[];
  for(const v of editingVariants.filter(v=>String(v.name||'').trim())){const vid=v.id||crypto.randomUUID();v.id=vid;const img=await uploadVariantImage(vid,v.file,v.image_url);v.image_url=img;cleanVariants.push({id:vid,product_id:id,name:String(v.name).trim(),price:Number(pprice.value||0),stock:0,weight_grams:weight,image_url:img,is_active:true});}
  // preserve old records but deactivate removed ones
  for(const oldV of oldVariants.filter(oldV=>!cleanVariants.some(newV=>String(newV.id)===String(oldV.id)))) await api('/rest/v1/product_variants?id=eq.'+encodeURIComponent(oldV.id),{method:'PATCH',headers:{'Prefer':'return=minimal'},body:JSON.stringify({is_active:false})});
  for(const oldS of oldSizes.filter(oldS=>!cleanSizes.some(newS=>String(newS.id)===String(oldS.id)))) await api('/rest/v1/product_sizes?id=eq.'+encodeURIComponent(oldS.id),{method:'PATCH',headers:{'Prefer':'return=minimal'},body:JSON.stringify({is_active:false})});
  const options=[];let aggregateStock=0, minPrice=null;
  cleanVariants.forEach(v=>{v.stock=0;cleanSizes.forEach(z=>{const o=optionFor(editingVariants.find(x=>String(x.id||'')===String(v.id))||{},z.id);const price=Number(o.price||0);const stock=Number(o.stock||0);const wg=Math.max(1,Math.min(1000,Number(o.weight_grams||weight)));options.push({id:crypto.randomUUID(),product_id:id,variant_id:v.id,size_id:z.id,price,stock,weight_grams:wg,image_url:v.image_url,is_active:true});aggregateStock+=stock;if(minPrice===null||price<minPrice)minPrice=price;});});
  const body={name:pname.value,brand:pbrand.value,category:pcat.value,description:pdesc.value,price:minPrice??Number(pprice.value||0),stock:cleanVariants.length&&cleanSizes.length?aggregateStock:Number(pstock.value||0),weight_grams:weight,is_active:pactive.value==='true',image_url};
  await api('/rest/v1/products'+(pid.value?`?id=eq.${encodeURIComponent(id)}`:''),{method:pid.value?'PATCH':'POST',headers:{'Prefer':'return=minimal'},body:JSON.stringify(pid.value?body:{id,...body})});
  if(cleanVariants.length) await api('/rest/v1/product_variants',{method:'POST',headers:{'Prefer':'resolution=merge-duplicates,return=minimal'},body:JSON.stringify(cleanVariants)});
  if(cleanSizes.length) await api('/rest/v1/product_sizes',{method:'POST',headers:{'Prefer':'resolution=merge-duplicates,return=minimal'},body:JSON.stringify(cleanSizes)});
  await api('/rest/v1/product_variant_options?product_id=eq.'+encodeURIComponent(id),{method:'DELETE'});
  if(options.length) await api('/rest/v1/product_variant_options',{method:'POST',headers:{'Prefer':'return=minimal'},body:JSON.stringify(options)});
  if(files.length){
    await api('/rest/v1/product_images?product_id=eq.'+encodeURIComponent(id),{method:'DELETE'});
    const rows=[];
    for(let i=0;i<files.length;i++){const url=i===0?image_url:await uploadProductImage(id,files[i],i);rows.push({id:crypto.randomUUID(),product_id:id,image_url:url,sort_order:i,is_active:true});}
    await api('/rest/v1/product_images',{method:'POST',headers:{'Prefer':'return=minimal'},body:JSON.stringify(rows)});
  }
  productMsg.textContent='Tersimpan ✓';resetProduct();await loadProducts();renderStats();
 }catch(e){productMsg.textContent='Gagal: '+e.message;console.error(e)}
}
async function deleteProduct(id){if(!confirm('Hapus produk ini?'))return;try{await api('/rest/v1/products?id=eq.'+encodeURIComponent(id),{method:'DELETE'});await loadProducts();renderStats()}catch(e){alert(e.message)}}
const statusLabel={pending:'Menunggu',processing:'Diproses',shipped:'Dikirim',completed:'Selesai',cancelled:'Dibatalkan'};
const paymentLabel={unpaid:'Belum dibayar',awaiting_verification:'Menunggu verifikasi',paid:'Sudah dibayar'};
function renderOrders(){
 const f=document.getElementById('orderFilter')?.value||'all';
 const q=(document.getElementById('orderSearch')?.value||'').trim().toLocaleLowerCase('id-ID');
 let list=orders.filter(o=>(f==='all'||(f==='shipping_pending'&&o.shipping_confirmed===false)||(f==='payment_pending'&&o.payment_status==='unpaid')||(['pending','processing','shipped','completed','cancelled'].includes(f)&&o.status===f)) && (!q||[o.id,o.customer_name,o.customer_phone,o.customer_address,o.shipping_courier].some(v=>String(v??'').toLocaleLowerCase('id-ID').includes(q))));
 list.sort((a,b)=>{const ap=a.shipping_confirmed===false?0:(a.payment_status==='unpaid'?1:2);const bp=b.shipping_confirmed===false?0:(b.payment_status==='unpaid'?1:2);return ap-bp||new Date(b.created_at)-new Date(a.created_at)});
 const info=document.getElementById('orderFilterInfo');if(info)info.textContent=`Menampilkan ${list.length} dari ${orders.length} pesanan`;
 orderRows.innerHTML=list.map(o=>{const shippingPending=o.shipping_confirmed===false;const payPending=o.payment_status==='unpaid';const courier=String(o.shipping_courier||'').toLowerCase();let actionBadge='';if(shippingPending)actionBadge='<span class="badge badge-wait">⏳ Konfirmasi ongkir</span>';else if(payPending)actionBadge='<span class="badge badge-pay">💳 Menunggu pembayaran</span>';else actionBadge='<span class="badge badge-ok">✓ Tidak ada tindakan</span>';return `<tr><td>#${o.id}</td><td><b>${esc(o.customer_name)}</b><br>${esc(o.customer_phone)}<br><span class="muted">${esc(o.customer_address)}</span></td><td>${money(o.total_amount)}<br><span class="muted">${esc(o.shipping_courier||'-')}</span></td><td>${esc(paymentLabel[o.payment_status]||o.payment_status||'-')}<br>${actionBadge}</td><td><select onchange="updateStatus(${o.id},this.value)">${['pending','processing','shipped','completed','cancelled'].map(s=>`<option ${o.status===s?'selected':''} value="${s}">${statusLabel[s]}</option>`).join('')}</select></td><td>${new Date(o.created_at).toLocaleString('id-ID')}</td><td><div class="row-actions"><button class="btn secondary" onclick="loadOrderItems(${o.id})">Detail</button><button class="btn danger" onclick="deleteOrder(${o.id})">Hapus</button></div></td></tr>`}).join('');
}
async function updateStatus(id,status){try{await api('/rest/v1/orders?id=eq.'+id,{method:'PATCH',headers:{'Prefer':'return=minimal'},body:JSON.stringify({status})});await loadOrders();renderStats()}catch(e){alert(e.message)}}
async function deleteOrder(id){if(!confirm('Hapus pesanan #'+id+'? Tindakan ini tidak dapat dibatalkan.'))return;try{await api('/rest/v1/order_items?order_id=eq.'+encodeURIComponent(id),{method:'DELETE',headers:{'Prefer':'return=minimal'}});await api('/rest/v1/orders?id=eq.'+encodeURIComponent(id),{method:'DELETE',headers:{'Prefer':'return=minimal'}});orders=orders.filter(o=>String(o.id)!==String(id));renderOrders();renderStats();renderNewOrderAlert();alert('Pesanan #'+id+' berhasil dihapus.')}catch(e){alert('Gagal menghapus pesanan: '+(e.message||e)+'. Jika pesanan memiliki riwayat chat atau data terkait, hapus relasi terkait terlebih dahulu.')}}
let currentOrderForWhatsApp=null;
function chatWhatsApp(){
  const o=currentOrderForWhatsApp;
  if(!o || !o.customer_phone){alert('Nomor WhatsApp pelanggan tidak tersedia.');return;}
  let phone=String(o.customer_phone).replace(/\D/g,'');
  if(phone.startsWith('0')) phone='62'+phone.slice(1);
  const status=statusLabel[o.status]||o.status||'-';
  const payment=paymentLabel[o.payment_status]||o.payment_status||'-';
  const total=money(o.total_amount);
  const msg=`Halo Kak ${o.customer_name||''},\n\nPesanan #${o.id} di Givitshop sudah kami terima.\nTotal: ${total}\nStatus pembayaran: ${payment}\nStatus pesanan: ${status}\n\nTerima kasih dan mohon menunggu ya kak \u{1F60A}`;
  window.open('https://wa.me/'+phone+'?text='+encodeURIComponent(msg),'_blank');
}
async function loadOrderItems(id){try{markOrderSeen(id);const o=orders.find(x=>String(x.id)===String(id));currentOrderForWhatsApp=o;const d=await api('/rest/v1/order_items?select=*&order_id=eq.'+id);document.getElementById('detailOrderId').textContent='Pesanan #'+id;document.getElementById('detailName').textContent=o?.customer_name||'-';document.getElementById('detailPhone').textContent=o?.customer_phone||'-';document.getElementById('detailAddress').textContent=o?.customer_address||'-';document.getElementById('detailPayment').textContent=paymentLabel[o?.payment_status]||o?.payment_status||'-';document.getElementById('detailStatus').textContent=statusLabel[o?.status]||o?.status||'-';document.getElementById('detailItems').innerHTML=d.length?d.map(x=>`<div class="item-row"><div><div class="item-name">${esc(x.product_name)}</div><div class="muted">${x.quantity} × ${money(x.price)}</div></div><b>${money(x.subtotal)}</b></div>`).join(''):'<div class="muted">Tidak ada item</div>';const subtotal=d.reduce((s,x)=>s+Number(x.subtotal||0),0);const total=Number(o?.total_amount||0);const shipping=Number(o?.shipping_cost||0);document.getElementById('detailSubtotal').textContent=money(subtotal);document.getElementById('detailShipping').textContent=money(shipping);document.getElementById('detailTotal').textContent=money(total);document.getElementById('detailCourier').textContent=o?.shipping_courier||'-';document.getElementById('detailService').textContent=o?.shipping_service||'-';document.getElementById('detailWeight').textContent=o?.shipping_weight_grams?Number(o.shipping_weight_grams).toLocaleString('id-ID')+' g':'-';document.getElementById('detailShippingStatus').textContent=o?.shipping_confirmed===false?'⏳ Menunggu konfirmasi':'✅ Terkonfirmasi';const manual=['grabexpress','maxim'].includes(String(o?.shipping_courier||'').toLowerCase())&&o?.shipping_confirmed===false;document.getElementById('manualShippingBox').style.display=manual?'block':'none';if(manual){document.getElementById('shippingCourier').value=String(o.shipping_courier).toLowerCase();document.getElementById('shippingService').value=o.shipping_service||'Instant';document.getElementById('shippingCost').value='';}document.getElementById('detailModal').classList.remove('hidden')}catch(e){alert(e.message)}}
async function confirmShipping(){try{if(!currentOrderForWhatsApp)return;const courier=shippingCourier.value;const service=shippingService.value.trim()||'Instant';const cost=Number(shippingCost.value||0);if(cost<0){alert('Ongkir tidak valid.');return;}await api('/rest/v1/rpc/confirm_shipping',{method:'POST',body:JSON.stringify({p_order_id:Number(currentOrderForWhatsApp.id),p_shipping_courier:courier,p_shipping_service:service,p_shipping_cost:cost})});await loadOrders();renderStats();await loadOrderItems(currentOrderForWhatsApp.id);alert('Ongkir berhasil dikonfirmasi.');}catch(e){alert(e.message)}}



function resetProductPromoForm(){
 ['productPromoId','productPromoTitle','productPromoValue','productPromoStart','productPromoEnd','productPromoLimit','productPromoSearch'].forEach(id=>document.getElementById(id).value='');
 Array.from(document.getElementById('productPromoProduct').options).forEach(o=>o.selected=false);filterProductPromoOptions();document.getElementById('productPromoType').value='percent';document.getElementById('productPromoActive').value='true';document.getElementById('productPromoMsg').textContent='';
}
function filterProductPromoOptions(){
 const q=(document.getElementById('productPromoSearch')?.value||'').trim().toLocaleLowerCase('id-ID');
 Array.from(document.getElementById('productPromoProduct')?.options||[]).forEach(o=>{if(!o.value){o.hidden=!!q;return;}o.hidden=!!q&&!o.textContent.toLocaleLowerCase('id-ID').includes(q);});
}
function promoLocalDate(value){if(!value)return '';const d=new Date(value);if(Number.isNaN(d.getTime()))return '';return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16)}
async function loadProductPromos(){
 const body=document.getElementById('productPromoRows'),select=document.getElementById('productPromoProduct');if(!body||!select)return;
 body.innerHTML='<tr><td colspan="6">Memuat promo...</td></tr>';
 try{
  const [ps,promos]=await Promise.all([api('/rest/v1/products?select=id,name,brand&order=name.asc'),api('/rest/v1/product_promotions?select=*&order=created_at.desc')]);
  const previous=Array.from(select.selectedOptions).map(o=>String(o.value));select.innerHTML=ps.map(p=>`<option value="${esc(p.id)}">${esc(p.name)}${p.brand?' — '+esc(p.brand):''}</option>`).join('');
  Array.from(select.options).forEach(o=>o.selected=previous.includes(String(o.value)));filterProductPromoOptions();
  window.givitProductPromos=promos;window.givitPromoProducts=ps;
  const grouped=new Map();promos.forEach(p=>{const key=String(p.title||'Promo Givitshop').trim().toLocaleLowerCase('id-ID');if(!grouped.has(key))grouped.set(key,{title:p.title||'Promo Givitshop',items:[]});grouped.get(key).items.push(p)});
  const groups=Array.from(grouped.values());
  body.innerHTML=groups.length?groups.map(g=>{const p=g.items[0],names=g.items.map(x=>ps.find(y=>String(y.id)===String(x.product_id))?.name||'Produk tidak ditemukan'),used=g.items.reduce((n,x)=>n+Number(x.used_count||0),0),active=g.items.every(x=>!!x.is_active),sameLimit=g.items.every(x=>String(x.usage_limit??'')===String(p.usage_limit??''));return `<tr><td><b>${names.map(esc).join('<br>')}</b><br><span class="muted">${esc(g.title)} · ${g.items.length} produk</span></td><td>${p.discount_type==='percent'?Number(p.discount_value)+'%':money(p.discount_value)}</td><td>${p.start_at?new Date(p.start_at).toLocaleString('id-ID'):'Sekarang'} — ${p.end_at?new Date(p.end_at).toLocaleString('id-ID'):'Tanpa batas akhir'}</td><td>${used}${sameLimit&&p.usage_limit!=null?' / '+Number(p.usage_limit)+' per produk':''}</td><td>${active?'<span style="color:#16804a">Aktif</span>':g.items.some(x=>x.is_active)?'Sebagian aktif':'Nonaktif'}</td><td><button class="btn secondary" onclick="editProductPromo('${p.id}')">Edit</button> <button class="btn secondary" onclick="setProductPromoActive('${p.id}',${!active})">${active?'Nonaktifkan semua':'Aktifkan semua'}</button> <button class="btn danger" onclick="deleteProductPromo('${p.id}')">Hapus semua</button></td></tr>`}).join(''):'<tr><td colspan="6">Belum ada promo produk.</td></tr>';
 }catch(e){body.innerHTML=`<tr><td colspan="6">Gagal memuat promo: ${esc(e.message||e)}. Jalankan PRODUCT_PROMOTIONS_V34.sql di Supabase terlebih dahulu.</td></tr>`}
}
function editProductPromo(id){
 const p=(window.givitProductPromos||[]).find(x=>String(x.id)===String(id));if(!p)return;
 document.getElementById('productPromoId').value=p.id;Array.from(document.getElementById('productPromoProduct').options).forEach(o=>o.selected=String(o.value)===String(p.product_id));document.getElementById('productPromoSearch').value='';filterProductPromoOptions();document.getElementById('productPromoTitle').value=p.title||'';document.getElementById('productPromoType').value=p.discount_type;document.getElementById('productPromoValue').value=p.discount_value;document.getElementById('productPromoLimit').value=p.usage_limit??'';document.getElementById('productPromoStart').value=promoLocalDate(p.start_at);document.getElementById('productPromoEnd').value=promoLocalDate(p.end_at);document.getElementById('productPromoActive').value=String(!!p.is_active);document.getElementById('productPromoMsg').textContent='Mengedit promo produk.';document.getElementById('productPromosTab').scrollIntoView({behavior:'smooth',block:'start'});
}
async function saveProductPromo(){
 const msg=document.getElementById('productPromoMsg');msg.textContent='Menyimpan promo...';
 const id=document.getElementById('productPromoId').value,product_ids=Array.from(document.getElementById('productPromoProduct').selectedOptions).map(o=>o.value).filter(Boolean),title=document.getElementById('productPromoTitle').value.trim()||'Promo Givitshop',discount_type=document.getElementById('productPromoType').value,discount_value=Number(document.getElementById('productPromoValue').value),limitText=document.getElementById('productPromoLimit').value.trim(),start=document.getElementById('productPromoStart').value,end=document.getElementById('productPromoEnd').value,is_active=document.getElementById('productPromoActive').value==='true';
 if(!product_ids.length){msg.textContent='Pilih minimal satu produk. Kamu bisa memilih beberapa produk sekaligus.';return}
 if(!Number.isFinite(discount_value)||discount_value<=0||(discount_type==='percent'&&discount_value>100)){msg.textContent='Nilai diskon tidak valid. Persentase maksimal 100%.';return}
 if(limitText&&(!Number.isInteger(Number(limitText))||Number(limitText)<1)){msg.textContent='Batas penggunaan harus bilangan bulat minimal 1.';return}
 if(start&&end&&new Date(end)<=new Date(start)){msg.textContent='Waktu akhir harus setelah waktu mulai.';return}
 const basePayload={title,discount_type,discount_value,usage_limit:limitText?Number(limitText):null,start_at:start?new Date(start).toISOString():null,end_at:end?new Date(end).toISOString():null,is_active,updated_at:new Date().toISOString()};
 try{
  const existingPromos=window.givitProductPromos||[];
  for(let i=0;i<product_ids.length;i++){
   const product_id=product_ids[i];
   let existing=existingPromos.find(x=>String(x.product_id)===String(product_id));
   if(id&&String(existing?.id)!==String(id)&&i===0){existing=existingPromos.find(x=>String(x.id)===String(id))||existing;}
   const payload={...basePayload,product_id};
   if(existing){await api('/rest/v1/product_promotions?id=eq.'+encodeURIComponent(existing.id),{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify(payload)})}
   else{await api('/rest/v1/product_promotions',{method:'POST',headers:{Prefer:'return=minimal'},body:JSON.stringify(payload)})}
  }
  msg.textContent=`Promo berhasil disimpan untuk ${product_ids.length} produk.`;resetProductPromoForm();await loadProductPromos();
 }catch(e){msg.textContent='Gagal menyimpan promo: '+(e.message||e)+'. Pastikan SQL sudah dijalankan dan akun admin memiliki akses.'}
}
function getPromoGroupTitle(id){const p=(window.givitProductPromos||[]).find(x=>String(x.id)===String(id));return p?String(p.title||'Promo Givitshop').trim():'Promo Givitshop'}
async function setProductPromoActive(id,active){
 const title=getPromoGroupTitle(id);if(!confirm((active?'Aktifkan':'Nonaktifkan')+' semua produk dengan nama promo “'+title+'”?'))return;
 try{await api('/rest/v1/product_promotions?title=eq.'+encodeURIComponent(title),{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({is_active:active,updated_at:new Date().toISOString()})});await loadProductPromos()}
 catch(e){alert('Gagal mengubah status semua promo dengan nama tersebut: '+(e.message||e))}
}
async function deleteProductPromo(id){const title=getPromoGroupTitle(id);if(!confirm('Hapus semua promo dengan nama “'+title+'” beserta seluruh produk yang terkait? Tindakan ini tidak dapat dibatalkan.'))return;try{await api('/rest/v1/product_promotions?title=eq.'+encodeURIComponent(title),{method:'DELETE',headers:{Prefer:'return=minimal'}});await loadProductPromos();alert('Semua promo bernama “'+title+'” berhasil dihapus.')}catch(e){alert('Gagal menghapus promo: '+(e.message||e))}}

function resetVoucherForm(){['voucherId','voucherTitle','voucherCode','voucherValue','voucherLimit','voucherStart','voucherEnd','voucherDescription'].forEach(id=>document.getElementById(id).value='');document.getElementById('voucherType').value='percent';document.getElementById('voucherMin').value='0';document.getElementById('voucherActive').value='true';document.getElementById('voucherMsg').textContent=''}
function localDateInput(value){if(!value)return '';const d=new Date(value);if(Number.isNaN(d.getTime()))return '';return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16)}
function voucherPeriod(v){const f=d=>d?new Date(d).toLocaleString('id-ID'):'-';return f(v.start_at)+' — '+f(v.end_at)}
async function loadVouchers(){const body=document.getElementById('voucherRows');if(!body)return;body.innerHTML='<tr><td colspan="6">Memuat voucher...</td></tr>';try{const rows=await api('/rest/v1/vouchers?select=*&order=created_at.desc');window.givitVouchers=rows;body.innerHTML=rows.length?rows.map(v=>`<tr><td><b>${esc(v.title)}</b><br><span class="muted">${esc(v.code)}</span></td><td>${v.discount_type==='percent'?Number(v.discount_value)+'%':money(v.discount_value)}<br><span class="muted">Min. ${money(v.min_purchase||0)}</span></td><td>${esc(voucherPeriod(v))}</td><td>${Number(v.used_count||0)}${v.usage_limit==null?'':' / '+Number(v.usage_limit)}</td><td>${v.is_active?'<span style="color:#16804a">Aktif</span>':'Nonaktif'}</td><td><button class="btn secondary" onclick="editVoucher('${v.id}')">Edit</button> <button class="btn secondary" onclick="toggleVoucher('${v.id}',${!v.is_active})">${v.is_active?'Nonaktifkan':'Aktifkan'}</button> <button class="btn danger" onclick="deleteVoucher('${v.id}')">Hapus</button></td></tr>`).join(''):'<tr><td colspan="6">Belum ada voucher. Buat voucher melalui formulir di atas.</td></tr>'}catch(e){body.innerHTML=`<tr><td colspan="6">Gagal memuat voucher: ${esc(e.message||e)}. Pastikan SQL voucher sudah dijalankan.</td></tr>`}}
function editVoucher(id){const v=(window.givitVouchers||[]).find(x=>String(x.id)===String(id));if(!v)return;document.getElementById('voucherId').value=v.id;document.getElementById('voucherTitle').value=v.title||'';document.getElementById('voucherCode').value=v.code||'';document.getElementById('voucherType').value=v.discount_type||'percent';document.getElementById('voucherValue').value=v.discount_value||'';document.getElementById('voucherMin').value=v.min_purchase||0;document.getElementById('voucherLimit').value=v.usage_limit??'';document.getElementById('voucherStart').value=localDateInput(v.start_at);document.getElementById('voucherEnd').value=localDateInput(v.end_at);document.getElementById('voucherDescription').value=v.description||'';document.getElementById('voucherActive').value=String(!!v.is_active);document.getElementById('voucherMsg').textContent='Mengedit '+v.code;document.getElementById('vouchersTab').scrollIntoView({behavior:'smooth',block:'start'})}
async function saveVoucher(){const msg=document.getElementById('voucherMsg');msg.textContent='Menyimpan...';const title=document.getElementById('voucherTitle').value.trim(),code=document.getElementById('voucherCode').value.trim().toUpperCase(),type=document.getElementById('voucherType').value,value=Number(document.getElementById('voucherValue').value),min=Number(document.getElementById('voucherMin').value||0),limitText=document.getElementById('voucherLimit').value.trim(),start=document.getElementById('voucherStart').value,end=document.getElementById('voucherEnd').value;if(!title||!code||!Number.isFinite(value)||value<=0){msg.textContent='Nama, kode, dan nilai diskon wajib diisi dengan benar.';return}if(type==='percent'&&value>100){msg.textContent='Diskon persentase maksimal 100%.';return}if(min<0||(limitText&&Number(limitText)<1)){msg.textContent='Minimum belanja atau batas penggunaan tidak valid.';return}if(start&&end&&new Date(end)<=new Date(start)){msg.textContent='Waktu akhir harus setelah waktu mulai.';return}const payload={title,code,discount_type:type,discount_value:value,min_purchase:min,usage_limit:limitText?Number(limitText):null,start_at:start?new Date(start).toISOString():null,end_at:end?new Date(end).toISOString():null,description:document.getElementById('voucherDescription').value.trim(),is_active:document.getElementById('voucherActive').value==='true'};const id=document.getElementById('voucherId').value;try{if(id){await api('/rest/v1/vouchers?id=eq.'+encodeURIComponent(id),{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify(payload)})}else{payload.used_count=0;await api('/rest/v1/vouchers',{method:'POST',headers:{Prefer:'return=minimal'},body:JSON.stringify(payload)})}msg.textContent='Voucher berhasil disimpan.';resetVoucherForm();await loadVouchers()}catch(e){msg.textContent='Gagal menyimpan: '+(e.message||e)+'. Pastikan kode voucher unik dan SQL voucher sudah dijalankan.'}}
async function toggleVoucher(id,active){if(!confirm((active?'Aktifkan':'Nonaktifkan')+' voucher ini?'))return;try{await api('/rest/v1/vouchers?id=eq.'+encodeURIComponent(id),{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({is_active:active})});await loadVouchers()}catch(e){alert('Gagal mengubah status voucher: '+(e.message||e))}}
async function deleteVoucher(id){const v=(window.givitVouchers||[]).find(x=>String(x.id)===String(id));if(!confirm('Hapus voucher '+(v?.code||'ini')+'? Tindakan ini tidak dapat dibatalkan.'))return;try{await api('/rest/v1/vouchers?id=eq.'+encodeURIComponent(id),{method:'DELETE',headers:{Prefer:'return=minimal'}});await loadVouchers();alert('Voucher berhasil dihapus.')}catch(e){alert('Gagal menghapus voucher: '+(e.message||e))}}

function closeDetail(e){if(!e||e.target?.id==='detailModal')document.getElementById('detailModal').classList.add('hidden')}
function showTab(t){productsTab.classList.toggle('hidden',t!=='products');ordersTab.classList.toggle('hidden',t!=='orders');chatTab.classList.toggle('hidden',t!=='chat');vouchersTab.classList.toggle('hidden',t!=='vouchers');productPromosTab.classList.toggle('hidden',t!=='productPromos');tabProducts.classList.toggle('active',t==='products');tabOrders.classList.toggle('active',t==='orders');tabChat.classList.toggle('active',t==='chat');tabVouchers.classList.toggle('active',t==='vouchers');tabProductPromos.classList.toggle('active',t==='productPromos');if(t==='chat')loadChatConversations();if(t==='vouchers')loadVouchers();if(t==='productPromos')loadProductPromos()}

let activeAdminConversation=null;
async function loadChatConversations(){
  const box=document.getElementById('chatRows');if(!box)return;
  try{
    const rows=await api('/rest/v1/chat_conversations?select=*&order=last_message_at.desc.nullslast');
    box.innerHTML=rows.length?rows.map(c=>`<tr><td>#${c.order_id}</td><td>${esc(c.customer_phone||'-')}</td><td>${esc(c.last_message_preview||'-')}</td><td>${c.last_message_at?new Date(c.last_message_at).toLocaleString('id-ID'):'-'}</td><td><button class="btn primary" onclick="openAdminChat('${c.id}','${c.order_id}')">Buka Chat</button></td></tr>`).join(''):'<tr><td colspan="5">Belum ada percakapan.</td></tr>';
  }catch(e){box.innerHTML=`<tr><td colspan="5">Gagal memuat chat: ${esc(e.message)}. Pastikan CHAT_SCHEMA.sql sudah dijalankan di Supabase.</td></tr>`;}
}
async function openAdminChat(id,orderId){
  activeAdminConversation={id,orderId};
  document.getElementById('adminChatTitle').textContent='Chat Pesanan #'+orderId;
  document.getElementById('adminChatModal').classList.remove('hidden');
  await loadAdminChatMessages();
}
async function loadAdminChatMessages(){
  const c=activeAdminConversation;if(!c)return;
  const box=document.getElementById('adminChatMessages');box.innerHTML='Memuat pesan...';
  try{
    const rows=await api('/rest/v1/chat_messages?select=id,sender_role,message,created_at&conversation_id=eq.'+encodeURIComponent(c.id)+'&order=created_at.asc');
    box.innerHTML=rows.map(m=>`<div style="display:flex;justify-content:${m.sender_role==='admin'?'flex-end':'flex-start'};margin:8px 0"><div style="max-width:85%;padding:10px 12px;border-radius:14px;background:${m.sender_role==='admin'?'#e85b7a':'#f4eef1'};color:${m.sender_role==='admin'?'#fff':'#28242a'};white-space:pre-wrap;overflow-wrap:anywhere">${esc(m.message)}<div class="muted" style="margin-top:5px;color:inherit">${new Date(m.created_at).toLocaleString('id-ID')}</div></div></div>`).join('')||'<p class="muted">Belum ada pesan.</p>';
    box.scrollTop=box.scrollHeight;
  }catch(e){box.innerHTML='Gagal memuat pesan: '+esc(e.message);}
}
async function sendAdminChatMessage(){
  const c=activeAdminConversation,input=document.getElementById('adminChatInput');const message=(input?.value||'').trim();
  if(!c||!message)return;if(message.length>2000){alert('Pesan maksimal 2.000 karakter.');return;}
  try{
    await api('/rest/v1/chat_messages',{method:'POST',headers:{'Prefer':'return=minimal'},body:JSON.stringify({conversation_id:c.id,sender_role:'admin',message})});
    await api('/rest/v1/chat_conversations?id=eq.'+encodeURIComponent(c.id),{method:'PATCH',headers:{'Prefer':'return=minimal'},body:JSON.stringify({last_message_preview:message.slice(0,160),last_message_at:new Date().toISOString(),last_sender_role:'admin'})});
    input.value='';await loadAdminChatMessages();await loadChatConversations();
  }catch(e){alert('Gagal mengirim balasan: '+e.message);}
}
function closeAdminChat(){document.getElementById('adminChatModal').classList.add('hidden');activeAdminConversation=null;}
setInterval(()=>{if(activeAdminConversation&&!document.getElementById('adminChatModal').classList.contains('hidden'))loadAdminChatMessages();if(!document.getElementById('chatTab')?.classList.contains('hidden'))loadChatConversations();},7000);

renderVariantEditor();renderSizeEditor();
loadSeenOrderIds();
token=sessionStorage.getItem('givit_admin_token');if(token){document.getElementById('login').classList.add('hidden');document.getElementById('app').classList.remove('hidden');refresh().catch(()=>logout())}
