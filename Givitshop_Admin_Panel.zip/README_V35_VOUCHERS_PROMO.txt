GIVITSHOP V35 — VOUCHER & BATAS PENGGUNAAN PROMO

PENTING: Jalankan GIVITSHOP_VOUCHERS_PROMO_V35.sql di Supabase SQL Editor sebelum menggunakan tab Voucher atau Promo Diskon Produk.
Langkah:
1. Buka Supabase Dashboard > SQL Editor > New query.
2. Tempel seluruh isi file GIVITSHOP_VOUCHERS_PROMO_V35.sql.
3. Klik Run dan pastikan tidak ada error.
4. Deploy panel admin terbaru.
5. Build APK pembeli menggunakan main_v35.yml.
Batas penggunaan promo produk dihitung satu kali per pesanan yang berisi produk tersebut. Saat batas tercapai, promo tidak berlaku untuk pesanan baru. Batas voucher berlaku sesuai kolom usage_limit pada tabel vouchers.
