GIVITSHOP ADMIN V44 - FOTO BANNER BERANDA

Fitur:
- Tab baru "Foto Beranda" pada panel admin.
- Admin dapat memilih, melihat pratinjau, mengunggah, menyimpan, dan menghapus foto banner beranda.
- Aplikasi pembeli membaca URL foto dari public.homepage_settings (id='main').
- Desain lain tidak diubah.

Pemasangan:
1. Jalankan HOME_BANNER_SETTINGS.sql di Supabase SQL Editor.
2. Pastikan Storage bucket public bernama product-images sudah ada (digunakan oleh foto produk saat ini).
3. Ganti ZIP admin di repository dengan versi ini tetapi gunakan nama yang dibaca workflow: Givitshop_Admin_Panel.zip.
4. Jalankan GitHub Actions > Deploy Givitshop Admin.
5. Untuk aplikasi pembeli, gunakan Givitshop_Siap_Build_Foto_Beranda_V38.zip dan workflow Build Givitshop APK.
6. Setelah build selesai, instal APK baru.

Catatan keamanan:
- SQL hanya memberi hak tulis kepada user yang JWT app_metadata role-nya admin.
- Jika upload foto ditolak Storage, periksa policy bucket product-images. Jangan memasukkan service_role key ke HTML.
