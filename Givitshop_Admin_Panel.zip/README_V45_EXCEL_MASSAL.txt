GIVITSHOP ADMIN V45 - UPLOAD PRODUK MASSAL EXCEL

Fitur:
- Unduh template Excel .xlsx berisi sheet Produk dan Panduan.
- Isi satu produk per baris, lalu pratinjau dan validasi.
- Import banyak produk ke tabel Supabase products secara batch.
- Laporan CSV untuk baris yang gagal.
- Kolom: name (wajib), price (wajib), stock (wajib), brand, category, description,
  weight_grams (1-1000; default 1000), is_active (TRUE/FALSE; default TRUE),
  image_url (opsional URL publik).
- Foto dari komputer tidak bisa ditempel langsung di Excel. Isi image_url dengan URL publik,
  atau tambahkan foto setelah produk diimpor melalui form produk yang sudah ada.
- SheetJS dimuat dari CDN jsDelivr, sehingga browser admin memerlukan internet.

File admin/index.html diperbarui dari Givitshop_Admin_Panel_V44.zip.
Fitur admin lain dan file pendukung V44 dipertahankan.
