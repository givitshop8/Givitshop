GIVITSHOP ADMIN PANEL V41

Perubahan: pada formulir Voucher ada pencarian produk dan pilihan beberapa produk. Voucher mewajibkan minimal satu produk. Edit voucher memuat pilihan yang tersimpan. Daftar voucher menampilkan produk terkait. Fitur admin lainnya dipertahankan.

PENTING: sebelum menyimpan voucher V41, jalankan VOUCHER_PRODUCT_SELECTION_V41.sql di Supabase SQL Editor. Kolom product_ids memakai UUID[] dan mengharuskan ID produk berbentuk UUID.

Pembatasan diskon saat checkout juga harus diterapkan di kode aplikasi pembeli/server checkout: hanya item dengan product_id yang ada dalam vouchers.product_ids yang boleh mendapat diskon. ZIP ini memperbarui panel admin dan skema database, bukan APK pembeli.
