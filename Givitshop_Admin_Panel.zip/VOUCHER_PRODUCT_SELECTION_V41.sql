-- Givitshop V41: simpan produk yang dipilih untuk setiap voucher.
-- Jalankan sekali di Supabase SQL Editor sebelum memakai formulir voucher V41.
alter table public.vouchers add column if not exists product_ids uuid[] not null default '{}'::uuid[];

-- Catatan: checkout aplikasi pembeli harus memeriksa product_ids sebelum memberi diskon.
-- Voucher V41 mewajibkan minimal satu produk dipilih pada panel admin.
