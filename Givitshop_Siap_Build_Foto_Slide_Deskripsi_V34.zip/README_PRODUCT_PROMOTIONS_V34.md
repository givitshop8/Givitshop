# Givitshop V34 — Promo Diskon Produk Otomatis

Perubahan khusus:
- Admin dapat membuat promo diskon untuk satu produk tertentu.
- Diskon persentase atau nominal, tanggal mulai/akhir, aktif/nonaktif.
- Harga promo terlihat pada kartu produk, detail produk, modal pilih varian, dan keranjang.
- RPC `place_order` menghitung ulang harga promo di database saat order dibuat.
- Perubahan desain dan fitur lain dipertahankan dari V33.

## Pemasangan
1. Di Supabase SQL Editor, jalankan seluruh `PRODUCT_PROMOTIONS_V34.sql`.
2. Unggah ZIP ini ke root repository GitHub.
3. Ganti `.github/workflows/main.yml` dengan `main_v34.yml`, commit, lalu jalankan Build Givitshop APK.
4. Untuk panel admin, unggah `Givitshop_Admin_Panel_V34.zip` yang disertakan terpisah ke root repository. Pastikan workflow Deploy Givitshop Admin berhasil.
5. Uji satu produk percobaan, misalnya diskon 10%, cek harga katalog/detail/keranjang, lalu buat pesanan uji sebelum promo dipakai secara langsung.

Catatan:
- Satu promo per produk dalam satu waktu.
- Harga di database saat pesanan dibuat adalah acuan. Promo yang diaktifkan setelah checkout tidak mengubah pesanan lama.
- Perubahan harga hanya berlaku pada produk yang dipilih; produk lain tetap harga normal.
